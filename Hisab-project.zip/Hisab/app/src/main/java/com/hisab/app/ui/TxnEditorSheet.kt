@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hisab.app.data.*
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Bottom sheet to add or edit an entry (cash, UPI, bank or card). */
@Composable
fun TxnEditorSheet(req: EditorRequest, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val e = req.existing
    var type by remember { mutableStateOf(e?.type ?: req.type) }
    var amountText by remember { mutableStateOf(e?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var mode by remember { mutableStateOf(e?.mode ?: req.mode) }
    var category by remember { mutableStateOf(e?.category ?: if (req.type == TxnType.CREDIT) Category.OTHER else Category.FOOD) }
    var party by remember { mutableStateOf(e?.party ?: "") }
    var note by remember { mutableStateOf(e?.note ?: "") }
    var dateTime by remember {
        mutableStateOf(
            e?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it.time), ZoneId.systemDefault()) } ?: LocalDateTime.now()
        )
    }
    var confirmDelete by remember { mutableStateOf(false) }
    val amount = amountText.replace(",", "").toDoubleOrNull()
    val accent = if (type == TxnType.DEBIT) SpendRed else EarnGreen

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding()
        ) {
            Text(if (e == null) "New entry" else "Edit entry", style = MaterialTheme.typography.titleLarge)
            if (e?.isAuto == true) {
                Text(
                    "Captured automatically. You can fix the name or category.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(16.dp))

            // Spent / Received toggle
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TypeButton("Spent", Icons.Rounded.ArrowUpward, SpendRed, type == TxnType.DEBIT, Modifier.weight(1f)) { type = TxnType.DEBIT }
                TypeButton("Received", Icons.Rounded.ArrowDownward, EarnGreen, type == TxnType.CREDIT, Modifier.weight(1f)) { type = TxnType.CREDIT }
            }
            Spacer(Modifier.height(16.dp))

            // Amount
            OutlinedTextField(
                value = amountText,
                onValueChange = { v -> if (v.length <= 12 && v.all { it.isDigit() || it == '.' || it == ',' }) amountText = v },
                modifier = Modifier.fillMaxWidth(),
                prefix = { Text("₹ ", fontSize = 28.sp, color = accent) },
                textStyle = MaterialTheme.typography.headlineLarge.copy(color = accent),
                placeholder = { Text("0", fontSize = 28.sp) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true, shape = RoundedCornerShape(16.dp),
                label = { Text("Amount") }
            )
            Spacer(Modifier.height(16.dp))

            // Payment mode
            Text("Paid by", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mode.entries.forEach { m ->
                    FilterChip(
                        selected = mode == m, onClick = { mode = m },
                        label = { Text(m.label, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            // Category grid
            Text("Category", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Category.entries.toList().chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { c -> CategoryTile(c, category == c, Modifier.weight(1f)) { category = c } }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = party, onValueChange = { party = it.take(40) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(if (type == TxnType.DEBIT) "Paid to (shop / person)" else "Received from") },
                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = note, onValueChange = { note = it.take(120) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Note (optional)") },
                leadingIcon = { Icon(Icons.Rounded.Notes, null) },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(10.dp))

            // Date & time
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(context, { _, y, m, d -> dateTime = dateTime.withYear(y).withMonth(m + 1).withDayOfMonth(d) },
                            dateTime.year, dateTime.monthValue - 1, dateTime.dayOfMonth).apply {
                            datePicker.maxDate = System.currentTimeMillis()
                        }.show()
                    },
                    modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.CalendarMonth, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                    Text(dateTime.format(DateTimeFormatter.ofPattern("d MMM yyyy")))
                }
                OutlinedButton(
                    onClick = {
                        TimePickerDialog(context, { _, h, min -> dateTime = dateTime.withHour(h).withMinute(min) },
                            dateTime.hour, dateTime.minute, false).show()
                    },
                    modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.Schedule, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                    Text(dateTime.format(DateTimeFormatter.ofPattern("h:mm a")))
                }
            }
            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    val a = amount ?: 0.0
                    if (a > 0) Repository.save(
                        Txn(
                            id = e?.id ?: 0, amount = a, type = type, mode = mode, category = category,
                            party = party.trim(), note = note.trim(),
                            time = dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
                            source = e?.source ?: Source.MANUAL, raw = e?.raw ?: ""
                        )
                    )
                    onDismiss()
                },
                enabled = amount != null && amount > 0,
                modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent)
            ) {
                Text(if (e == null) "Save" else "Update", style = MaterialTheme.typography.titleMedium, color = Color.White)
            }
            if (e != null) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Delete, null, tint = SpendRed); Spacer(Modifier.width(6.dp))
                    Text("Delete entry", color = SpendRed)
                }
            }
        }
    }

    if (confirmDelete && e != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this entry?") },
            text = { Text("${signedMoney(e)} · ${e.party.ifBlank { e.category.label }}") },
            confirmButton = {
                TextButton(onClick = { Repository.delete(e.id); confirmDelete = false; onDismiss() }) { Text("Delete", color = SpendRed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun TypeButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = modifier.height(52.dp), shape = RoundedCornerShape(14.dp),
        color = if (selected) color.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
        border = if (selected) BorderStroke(1.5.dp, color) else null
    ) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (selected) color else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, fontWeight = FontWeight.SemiBold, color = if (selected) color else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryTile(c: Category, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = modifier.height(76.dp), shape = RoundedCornerShape(14.dp),
        color = if (selected) c.color().copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = if (selected) BorderStroke(1.5.dp, c.color()) else null
    ) {
        Column(
            Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(c.icon(), null, tint = c.color(), modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(4.dp))
            Text(
                c.label.substringBefore(" &").substringBefore(" /"), fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}
