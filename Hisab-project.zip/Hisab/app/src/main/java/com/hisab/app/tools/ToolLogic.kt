package com.hisab.app.tools

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

/** Pure date logic (unit-tested): alerts at 9 AM on (due − N days), on the due day, and the day after if still unpaid. */
object BillLogic {
    fun nextAlert(dueDay: Int, remindBefore: Int, paid: Set<String>, now: LocalDateTime): LocalDateTime? {
        val start = YearMonth.from(now)
        for (k in 0..12) {
            val ym = start.plusMonths(k.toLong())
            if (ym.toString() in paid) continue
            val due = ym.atDay(minOf(dueDay, ym.lengthOfMonth()))
            val candidates = listOf(due.minusDays(remindBefore.toLong()), due, due.plusDays(1))
                .distinct().sorted().map { it.atTime(9, 0) }
            candidates.firstOrNull { it.isAfter(now) }?.let { return it }
        }
        return null
    }
}

/** Month bill for a service (pure, unit-tested). Only counts days from start date up to today. */
data class MonthBill(val daysCounted: Int, val daysCame: Int, val absents: Int, val totalQty: Double, val amount: Double)

object AttendanceLogic {
    fun bill(
        month: YearMonth, perDay: Boolean, rate: Double, salary: Double, allowedLeaves: Int,
        start: LocalDate, today: LocalDate, qtyOn: (LocalDate) -> Double
    ): MonthBill {
        val days = (1..month.lengthOfMonth()).map { month.atDay(it) }.filter { !it.isBefore(start) && !it.isAfter(today) }
        val qtys = days.map { qtyOn(it) }
        val came = qtys.count { it > 0 }
        val absents = days.size - came
        val totalQty = qtys.sum()
        val amount = if (perDay) totalQty * rate else {
            if (days.isEmpty()) 0.0 else {
                // salary is for the whole month; extra leaves beyond the allowed ones are deducted per day
                val perDaySalary = salary / month.lengthOfMonth()
                val workDaysShare = salary * days.size / month.lengthOfMonth()
                (workDaysShare - maxOf(0, absents - allowedLeaves) * perDaySalary).coerceAtLeast(0.0)
            }
        }
        return MonthBill(days.size, came, absents, totalQty, amount)
    }
}

