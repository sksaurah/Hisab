package com.hisab.app.tools

import kotlin.math.pow

/** Pure money/maths formulas (unit-tested). */
object MoneyMath {
    /** Monthly EMI for principal P, yearly rate r%, n months. */
    fun emi(principal: Double, yearlyRate: Double, months: Int): Double {
        if (months <= 0) return 0.0
        val r = yearlyRate / 12 / 100
        if (r == 0.0) return principal / months
        val f = (1 + r).pow(months)
        return principal * r * f / (f - 1)
    }

    fun simpleInterest(p: Double, rate: Double, years: Double) = p * rate * years / 100

    /** Compound interest, compounded [perYear] times a year. Returns final amount. */
    fun compoundAmount(p: Double, rate: Double, years: Double, perYear: Int) =
        p * (1 + rate / 100 / perYear).pow(perYear * years)

    data class Gst(val base: Double, val gst: Double, val total: Double)

    /** add = true: price is before GST. add = false: price already includes GST. */
    fun gst(amount: Double, rate: Double, add: Boolean): Gst =
        if (add) Gst(amount, amount * rate / 100, amount * (1 + rate / 100))
        else { val base = amount / (1 + rate / 100); Gst(base, amount - base, amount) }
}

/** Basic calculator: + − × ÷ % ( ) with correct order of operations. */
object BasicCalc {
    fun eval(input: String): Double {
        val s = input.replace('×', '*').replace('÷', '/').replace('−', '-').replace(" ", "")
        val p = P(s)
        val v = p.expr()
        if (p.i < s.length) throw IllegalArgumentException("Bad")
        return v
    }

    private class P(val s: String) {
        var i = 0
        private fun eat(c: Char) = if (i < s.length && s[i] == c) { i++; true } else false
        fun expr(): Double {
            var v = term()
            while (true) v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v }
        }
        private fun term(): Double {
            var v = unary()
            while (true) v = when {
                eat('*') -> v * unary()
                eat('/') -> { val d = unary(); if (d == 0.0) throw ArithmeticException("Can't divide by 0"); v / d }
                else -> return v
            }
        }
        private fun unary(): Double = if (eat('-')) -unary() else if (eat('+')) unary() else postfix()
        private fun postfix(): Double {
            var v = primary()
            while (eat('%')) v /= 100
            return v
        }
        private fun primary(): Double {
            if (eat('(')) { val v = expr(); eat(')'); return v }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("Bad")
            return s.substring(st, i).toDouble()
        }
    }
}
