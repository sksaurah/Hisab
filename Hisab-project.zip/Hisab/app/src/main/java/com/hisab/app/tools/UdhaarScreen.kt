@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Repository
import com.hisab.app.ui.EarnGreen
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard
import com.hisab.app.ui.SpendRed
import com.hisab.app.ui.money
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun UdhaarScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val all = rememberItems { Udhaar.all() }
    var showSettled by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Udhaar?>(null) }
    var adding by remember { mutableStateOf(false) }
    var addFor by remember { mutableStateOf<Udhaar?>(null) }   // prefill person when adding from a card
    var expanded by remember { mutableStateOf<String?>(null) }

    val open = all.filter { !it.settled }
    val toGet = open.filter { it.theyOwe }.sumOf { it.amount }
    val toGive = open.filter { !it.theyOwe }.sumOf { it.amount }
    val people = (if (showSettled) all else open).groupBy { it.person.trim().lowercase() }
        .map { (_, list) -> list }
        .sortedByDescending { l -> l.maxOf { it.date } }

    ToolScaffold("Udhaar Book", onBack, fabText = "Add", onFab = { addFor = null; adding = true }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryTile("You will get", money(toGet), EarnGreen, Modifier.weight(1f))
                    SummaryTile("You will give", money(toGive), SpendRed, Modifier.weight(1f))
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("People", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Text("Show settled", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = showSettled, onCheckedChange = { showSettled = it })
                }
            }
            if (people.isEmpty()) item {
                SectionCard {
                    EmptyState(Icons.Rounded.Handshake, "No udhaar yet", "Tap “Add” when you give or take money from someone.")
                }
            }
            people.forEach { list ->
                val name = list.first().person
                val key = name.trim().lowercase()
                val unsettled = list.filter { !it.settled }
                val net = unsettled.sumOf { if (it.theyOwe) it.amount else -it.amount }
                val phone = list.firstOrNull { it.phone.isNotBlank() }?.phone ?: ""
                item(key = "p$key") {
                    SectionCard {
                        Row(
                            Modifier.fillMaxWidth().clickable { expanded = if (expanded == key) null else key },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconCircle(Icons.Rounded.Person, if (net >= 0) EarnGreen else SpendRed)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    when {
                                        net > 0 -> "Will give you"
                                        net < 0 -> "You will give"
                                        else -> "All settled ✓"
                                    },
                                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                money(kotlin.math.abs(net)), style = MaterialTheme.typography.titleLarge,
                                color = if (net >= 0) EarnGreen else SpendRed
                            )
                        }
                        if (expanded == key) {
                            Spacer(Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            list.sortedByDescending { it.date }.forEach { u ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { editing = u }.padding(vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            (if (u.theyOwe) "You gave" else "You took") + if (u.settled) " · settled" else "",
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                        Text(
                                            u.date.format(DateTimeFormatter.ofPattern("d MMM yyyy")) + if (u.note.isNotBlank()) " · ${u.note}" else "",
                                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        money(u.amount), fontWeight = FontWeight.SemiBold,
                                        color = if (u.settled) MaterialTheme.colorScheme.onSurfaceVariant else if (u.theyOwe) EarnGreen else SpendRed
                                    )
                                }
                            }
                        }
                        if (net != 0.0 || expanded == key) {
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (net > 0) OutlinedButton(
                                    onClick = { sendWhatsAppReminder(context, name, phone, net) },
                                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                                ) { Icon(Icons.Rounded.Chat, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Remind") }
                                if (phone.isNotBlank()) OutlinedButton(
                                    onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) },
                                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                                ) { Icon(Icons.Rounded.Call, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Call") }
                                if (net != 0.0) OutlinedButton(
                                    onClick = { unsettled.forEach { Udhaar.save(it.copy(settled = true)) } },
                                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                                ) { Icon(Icons.Rounded.Done, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Settle") }
                            }
                            TextButton(onClick = { addFor = list.first(); adding = true }) { Text("+ Add entry for $name") }
                        }
                    }
                }
            }
        }
    }

    if (adding) UdhaarSheet(existing = null, prefill = addFor, onDone = { adding = false })
    editing?.let { UdhaarSheet(existing = it, prefill = null, onDone = { editing = null }) }
}

@Composable
private fun SummaryTile(label: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f))) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = color)
            Text(value, style = MaterialTheme.typography.titleLarge, maxLines = 1)
        }
    }
}

@Composable
private fun UdhaarSheet(existing: Udhaar?, prefill: Udhaar?, onDone: () -> Unit) {
    val context = LocalContext.current
    var theyOwe by remember { mutableStateOf(existing?.theyOwe ?: true) }
    var person by remember { mutableStateOf(existing?.person ?: prefill?.person ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: prefill?.phone ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.plain() ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var date by remember { mutableStateOf(existing?.date ?: LocalDate.now()) }
    var settled by remember { mutableStateOf(existing?.settled ?: false) }

    ModalBottomSheet(onDismissRequest = onDone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (existing == null) "New udhaar" else "Edit udhaar", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToggleBox("I gave", "They will return", EarnGreen, theyOwe, Modifier.weight(1f)) { theyOwe = true }
                ToggleBox("I took", "I will return", SpendRed, !theyOwe, Modifier.weight(1f)) { theyOwe = false }
            }
            Field(person, { person = it.take(40) }, "Person name", leading = Icons.Rounded.Person)
            Field(phone, { v -> if (v.all { it.isDigit() || it == '+' || it == ' ' }) phone = v.take(16) }, "Phone (for WhatsApp)", leading = Icons.Rounded.Call, phone = true)
            Field(amount, { amount = it.take(10) }, "Amount", number = true, prefix = "₹ ")
            Field(note, { note = it.take(80) }, "Note (optional)", leading = Icons.Rounded.Notes)
            OutlinedButton(
                onClick = {
                    DatePickerDialog(context, { _, y, m, d -> date = LocalDate.of(y, m + 1, d) }, date.year, date.monthValue - 1, date.dayOfMonth).show()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)
            ) { Icon(Icons.Rounded.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text(date.format(DateTimeFormatter.ofPattern("d MMM yyyy"))) }
            if (existing != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Settled (money returned)", modifier = Modifier.weight(1f))
                    Switch(checked = settled, onCheckedChange = { settled = it })
                }
            }
            PrimaryButton("Save", enabled = person.isNotBlank() && amount.toAmount() > 0) {
                Udhaar.save(Udhaar(existing?.id ?: 0, person.trim(), phone.trim(), amount.toAmount(), theyOwe, note.trim(), date, settled))
                onDone()
            }
            if (existing != null) {
                TextButton(onClick = { Repository.deleteItem(existing.id); onDone() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Delete", color = SpendRed)
                }
            }
        }
    }
}

@Composable
fun ToggleBox(title: String, sub: String, color: Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = modifier.height(64.dp), shape = RoundedCornerShape(14.dp),
        color = if (selected) color.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
        border = if (selected) BorderStroke(1.5.dp, color) else null
    ) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(title, fontWeight = FontWeight.SemiBold, color = if (selected) color else MaterialTheme.colorScheme.onSurface)
            Text(sub, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Opens WhatsApp with a polite reminder. Uses the saved number if there is one. */
fun sendWhatsAppReminder(context: Context, name: String, phone: String, amount: Double) {
    val msg = "Namaste $name 🙏\nJust a friendly reminder: ${money(amount)} is pending from you. " +
        "Please return it when convenient. Thank you!"
    val digits = phone.filter { it.isDigit() }
    val intent = if (digits.length >= 10) {
        val intl = if (digits.length == 10) "91$digits" else digits
        Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=${Uri.encode(msg)}"))
    } else {
        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg).setPackage("com.whatsapp")
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Send reminder"))
    }
}
