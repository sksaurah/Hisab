@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Prefs
import com.hisab.app.data.Repository
import com.hisab.app.steps.StepTracker
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StepsScreen(modifier: Modifier, resumeTick: Int) {
    val context = LocalContext.current
    val steps by Repository.steps.collectAsState()
    val goal by Prefs.stepGoal.collectAsState()
    val stride by Prefs.strideCm.collectAsState()
    var hasPermission by remember(resumeTick) { mutableStateOf(Permissions.activity(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPermission = Permissions.activity(context)
    }
    val hasSensor = remember { StepTracker.hasSensor(context) }

    // Live counting while this screen is open
    if (hasSensor && hasPermission) LiveStepListener(context)

    val today = LocalDate.now()
    val todaySteps = steps[today] ?: 0
    val week = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val weekValues = week.map { (steps[it] ?: 0).toFloat() }
    val weekTotal = weekValues.sum().toInt()
    val monthTotal = steps.filterKeys { YearMonth.from(it) == YearMonth.now() }.values.sum()
    val best = steps.filterKeys { it.isAfter(today.minusDays(30)) }.maxByOrNull { it.value }
    val goalDays = week.count { (steps[it] ?: 0) >= goal }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Steps", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
        }
        if (!hasSensor) {
            item { SectionCard { EmptyState(Icons.Rounded.DirectionsWalk, "No step sensor", "This phone doesn't have a step counter sensor.") } }
            return@LazyColumn
        }
        if (!hasPermission) item {
            SectionCard {
                EmptyState(Icons.Rounded.DirectionsWalk, "Allow step counting", "Hisab needs “Physical activity” permission to count your steps.")
                Button(onClick = { launcher.launch(Permissions.activityPerms) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
                    Text("Allow")
                }
            }
        }

        // Today ring
        item {
            SectionCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Ring(todaySteps.toFloat() / goal, StepBlue, 210.dp, 18.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.DirectionsWalk, null, tint = StepBlue)
                            Text(groupThousands(todaySteps), style = MaterialTheme.typography.headlineLarge)
                            Text("of ${groupThousands(goal)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth()) {
                        MiniStat(Icons.Rounded.Straighten, "%.2f km".format(StepTracker.distanceKm(todaySteps, stride)), "Distance", Modifier.weight(1f))
                        MiniStat(Icons.Rounded.LocalFireDepartment, "${StepTracker.calories(todaySteps)} kcal", "Calories", Modifier.weight(1f))
                        MiniStat(Icons.Rounded.Flag, "${(todaySteps * 100 / goal.coerceAtLeast(1))}%", "Goal", Modifier.weight(1f))
                    }
                    if (todaySteps >= goal) {
                        Spacer(Modifier.height(12.dp))
                        AssistChip(onClick = {}, label = { Text("Goal reached today! 🎉") }, leadingIcon = { Icon(Icons.Rounded.EmojiEvents, null) })
                    }
                }
            }
        }

        // Last 7 days
        item {
            SectionCard(title = "Last 7 days") {
                Bars(
                    weekValues,
                    week.map { if (it == today) "Today" else it.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()) },
                    StepBlue, goal = goal.toFloat()
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Goal reached on $goalDays of 7 days",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Stats
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("This week", groupThousands(weekTotal), "avg ${groupThousands(weekTotal / 7)}/day", Modifier.weight(1f))
                StatTile("This month", groupThousands(monthTotal), "%.1f km".format(StepTracker.distanceKm(monthTotal, stride)), Modifier.weight(1f))
            }
        }
        if (best != null) item {
            StatTile("Best day (30 days)", groupThousands(best.value), best.key.dayHeader(), Modifier.fillMaxWidth())
        }
        item {
            Text(
                "Steps are counted by your phone's built-in step sensor while the phone is with you. " +
                    "Counting starts from when you first opened Hisab.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
private fun LiveStepListener(context: Context) {
    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        var lastWrite = 0L
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val now = System.currentTimeMillis()
                if (now - lastWrite < 2000) return       // save at most every 2 s; skipped steps are counted next time
                lastWrite = now
                StepTracker.record(context, e.values[0].toLong())
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }
}

@Composable
private fun MiniStat(icon: ImageVector, value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = StepBlue, modifier = Modifier.size(20.dp))
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StatTile(label: String, value: String, sub: String, modifier: Modifier) {
    Card(
        modifier = modifier, shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StepBlue.copy(alpha = 0.09f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = StepBlue)
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
