package com.hisab.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.hisab.app.capture.ParsedTxn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

private class HisabDb(context: Context) : SQLiteOpenHelper(context, "hisab.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE txn(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL, type TEXT NOT NULL, mode TEXT NOT NULL, category TEXT NOT NULL,
                party TEXT NOT NULL, note TEXT NOT NULL, time INTEGER NOT NULL, source TEXT NOT NULL, raw TEXT NOT NULL)"""
        )
        db.execSQL("CREATE INDEX idx_txn_time ON txn(time)")
        db.execSQL("CREATE TABLE steps(day TEXT PRIMARY KEY, steps INTEGER NOT NULL)")
        createItems(db)
    }

    /** Generic table for the tools (udhaar, bills, medicines, notes...). Each row = one JSON object. */
    private fun createItems(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, json TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createItems(db)
    }
}

/**
 * Single place that stores everything. All data stays on the phone.
 * UI observes [txns] and [steps]; capture services write through here, so the
 * screen updates live when a payment notification arrives.
 */
object Repository {
    private lateinit var db: HisabDb
    private val _txns = MutableStateFlow<List<Txn>>(emptyList())
    val txns: StateFlow<List<Txn>> = _txns.asStateFlow()

    private val _steps = MutableStateFlow<Map<LocalDate, Int>>(emptyMap())
    val steps: StateFlow<Map<LocalDate, Int>> = _steps.asStateFlow()

    @Volatile private var ready = false

    @Synchronized
    fun init(context: Context) {
        if (ready) return
        db = HisabDb(context.applicationContext)
        ready = true
        reloadTxns()
        reloadSteps()
    }

    // ------------------------------------------------------------------ transactions

    @Synchronized
    private fun reloadTxns() {
        val list = mutableListOf<Txn>()
        db.readableDatabase.rawQuery("SELECT * FROM txn ORDER BY time DESC", null).use { c ->
            while (c.moveToNext()) {
                list += Txn(
                    id = c.getLong(c.getColumnIndexOrThrow("id")),
                    amount = c.getDouble(c.getColumnIndexOrThrow("amount")),
                    type = TxnType.valueOf(c.getString(c.getColumnIndexOrThrow("type"))),
                    mode = Mode.entries.firstOrNull { it.name == c.getString(c.getColumnIndexOrThrow("mode")) } ?: Mode.CASH,
                    category = Category.of(c.getString(c.getColumnIndexOrThrow("category"))),
                    party = c.getString(c.getColumnIndexOrThrow("party")),
                    note = c.getString(c.getColumnIndexOrThrow("note")),
                    time = c.getLong(c.getColumnIndexOrThrow("time")),
                    source = Source.entries.firstOrNull { it.name == c.getString(c.getColumnIndexOrThrow("source")) } ?: Source.MANUAL,
                    raw = c.getString(c.getColumnIndexOrThrow("raw"))
                )
            }
        }
        _txns.value = list
    }

    private fun values(t: Txn) = ContentValues().apply {
        put("amount", t.amount); put("type", t.type.name); put("mode", t.mode.name)
        put("category", t.category.name); put("party", t.party); put("note", t.note)
        put("time", t.time); put("source", t.source.name); put("raw", t.raw)
    }

    @Synchronized
    fun save(t: Txn) {
        if (t.id == 0L) db.writableDatabase.insert("txn", null, values(t))
        else db.writableDatabase.update("txn", values(t), "id=?", arrayOf(t.id.toString()))
        reloadTxns()
    }

    @Synchronized
    fun delete(id: Long) {
        db.writableDatabase.delete("txn", "id=?", arrayOf(id.toString()))
        reloadTxns()
    }

    @Synchronized
    fun deleteAll() {
        db.writableDatabase.delete("txn", null, null)
        db.writableDatabase.delete("steps", null, null)
        db.writableDatabase.delete("items", null, null)
        _itemsVersion.value++
        reloadTxns(); reloadSteps()
    }

    /**
     * Saves an automatically captured payment unless it's a duplicate.
     * The same payment often arrives twice (UPI app notification + bank SMS),
     * so the same amount and direction within 15 minutes is treated as one.
     * Returns true if it was saved.
     */
    @Synchronized
    fun addAuto(p: ParsedTxn, time: Long, source: Source, raw: String): Boolean {
        val window = 15 * 60 * 1000L
        val dup = _txns.value.any {
            it.isAuto && it.type == p.type && kotlin.math.abs(it.amount - p.amount) < 0.01 &&
                (kotlin.math.abs(it.time - time) < window || it.raw == raw)
        }
        if (dup) return false
        save(Txn(0, p.amount, p.type, p.mode, p.category, p.party, "", time, source, raw))
        return true
    }

    // ------------------------------------------------------------------ tool items (JSON rows)

    private val _itemsVersion = MutableStateFlow(0)
    /** Increases whenever any tool item changes; screens re-read their lists when it changes. */
    val itemsVersion: StateFlow<Int> = _itemsVersion.asStateFlow()

    @Synchronized
    fun items(kind: String): List<Pair<Long, org.json.JSONObject>> {
        val out = mutableListOf<Pair<Long, org.json.JSONObject>>()
        db.readableDatabase.rawQuery("SELECT id, json FROM items WHERE kind=? ORDER BY id", arrayOf(kind)).use { c ->
            while (c.moveToNext()) {
                runCatching { org.json.JSONObject(c.getString(1)) }.getOrNull()?.let { out += c.getLong(0) to it }
            }
        }
        return out
    }

    @Synchronized
    fun item(id: Long): org.json.JSONObject? =
        db.readableDatabase.rawQuery("SELECT json FROM items WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) runCatching { org.json.JSONObject(c.getString(0)) }.getOrNull() else null
        }

    /** Inserts (id = 0) or updates; returns the row id. */
    @Synchronized
    fun saveItem(kind: String, id: Long, json: org.json.JSONObject): Long {
        val cv = ContentValues().apply { put("kind", kind); put("json", json.toString()) }
        val newId = if (id == 0L) db.writableDatabase.insert("items", null, cv)
        else { db.writableDatabase.update("items", cv, "id=?", arrayOf(id.toString())); id }
        _itemsVersion.value++
        return newId
    }

    @Synchronized
    fun deleteItem(id: Long) {
        db.writableDatabase.delete("items", "id=?", arrayOf(id.toString()))
        _itemsVersion.value++
    }

    // ------------------------------------------------------------------ steps

    @Synchronized
    private fun reloadSteps() {
        val map = mutableMapOf<LocalDate, Int>()
        db.readableDatabase.rawQuery("SELECT day, steps FROM steps", null).use { c ->
            while (c.moveToNext()) map[LocalDate.parse(c.getString(0))] = c.getInt(1)
        }
        _steps.value = map
    }

    @Synchronized
    fun addSteps(day: LocalDate, delta: Int) {
        if (delta <= 0) return
        val current = _steps.value[day] ?: 0
        val cv = ContentValues().apply { put("day", day.toString()); put("steps", current + delta) }
        db.writableDatabase.insertWithOnConflict("steps", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        _steps.value = _steps.value + (day to current + delta)
    }
}
