@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hisab.app.data.*
import java.time.YearMonth
import java.time.format.DateTimeFormatter

private enum class Filter(val label: String) { ALL("All"), SPENT("Spent"), RECEIVED("Received"), CASH("Cash"), AUTO("Auto") }

@Composable
fun TransactionsScreen(modifier: Modifier, onOpen: (Txn) -> Unit) {
    val txns by Repository.txns.collectAsState()
    var month by remember { mutableStateOf(YearMonth.now()) }
    var filter by remember { mutableStateOf(Filter.ALL) }
    var query by remember { mutableStateOf("") }

    val shown = remember(txns, month, filter, query) {
        txns.filter { YearMonth.from(it.time.toLocalDate()) == month }
            .filter {
                when (filter) {
                    Filter.ALL -> true
                    Filter.SPENT -> it.type == TxnType.DEBIT
                    Filter.RECEIVED -> it.type == TxnType.CREDIT
                    Filter.CASH -> it.mode == Mode.CASH
                    Filter.AUTO -> it.isAuto
                }
            }
            .filter {
                query.isBlank() || it.party.contains(query, true) || it.note.contains(query, true) ||
                    it.category.label.contains(query, true) || money(it.amount).contains(query)
            }
    }
    val totalOut = shown.filter { it.type == TxnType.DEBIT && it.category.countsAsSpend }.sumOf { it.amount }
    val totalIn = shown.filter { it.type == TxnType.CREDIT }.sumOf { it.amount }
    val grouped = shown.groupBy { it.time.toLocalDate() }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "History", style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
            )
        }
        // Month switcher
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Rounded.ChevronLeft, "Previous month") }
                Text(
                    month.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                    style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                IconButton(onClick = { month = month.plusMonths(1) }, enabled = month < YearMonth.now()) {
                    Icon(Icons.Rounded.ChevronRight, "Next month")
                }
            }
        }
        // Totals
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TotalTile("Spent", money(totalOut), SpendRed, Modifier.weight(1f))
                TotalTile("Received", money(totalIn), EarnGreen, Modifier.weight(1f))
            }
        }
        // Search + filters
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search name, note, category") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Clear") } },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Filter.entries.toList()) { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) })
                }
            }
        }

        if (shown.isEmpty()) item {
            SectionCard { EmptyState(Icons.Rounded.ReceiptLong, "Nothing here", "No entries match this month and filter.") }
        }

        grouped.forEach { (day, list) ->
            item(key = "h$day") {
                Row(Modifier.padding(start = 4.dp, top = 6.dp)) {
                    Text(day.dayHeader(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    val daySpent = list.filter { it.type == TxnType.DEBIT && it.category.countsAsSpend }.sumOf { it.amount }
                    if (daySpent > 0) Text("− ${money(daySpent)}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item(key = "d$day") {
                SectionCard { list.forEach { TxnRow(it) { onOpen(it) } } }
            }
        }
    }
}

@Composable
private fun TotalTile(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Card(
        modifier = modifier, shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = color)
            Text(value, style = MaterialTheme.typography.titleLarge, maxLines = 1)
        }
    }
}
