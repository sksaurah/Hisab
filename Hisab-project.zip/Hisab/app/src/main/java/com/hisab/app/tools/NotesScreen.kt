@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hisab.app.data.Repository
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard
import com.hisab.app.ui.SpendRed
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val noteColors = listOf(
    Color(0xFFFFF4C2), Color(0xFFD7F5E3), Color(0xFFDDEBFF), Color(0xFFFFE0E0), Color(0xFFEDE3FF)
)
private val noteInk = Color(0xFF1F2421)
private val sizes = listOf("Large" to 24, "Extra large" to 30, "Huge" to 36)

private fun textSize(c: Context) = c.getSharedPreferences("notes", Context.MODE_PRIVATE).getInt("size", 30)
private fun setTextSize(c: Context, v: Int) = c.getSharedPreferences("notes", Context.MODE_PRIVATE).edit().putInt("size", v).apply()

@Composable
fun NotesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val notes = rememberItems { Note.all() }.sortedByDescending { it.created }
    var editing by remember { mutableStateOf<Note?>(null) }
    var adding by remember { mutableStateOf(false) }
    var size by remember { mutableIntStateOf(textSize(context)) }

    ToolScaffold("Big Notes", onBack, fabText = "New note", onFab = { adding = true }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.FormatSize, null)
                    sizes.forEach { (label, v) ->
                        FilterChip(selected = size == v, onClick = { size = v; setTextSize(context, v) }, label = { Text(label) })
                    }
                }
            }
            item { NotificationPermissionCard() }
            if (notes.isEmpty()) item {
                SectionCard { EmptyState(Icons.Rounded.StickyNote2, "No notes yet", "Write anything in big letters. Add a reminder and your phone will alert you.") }
            }
            items(notes, key = { it.id }) { n ->
                val bg = noteColors[n.color.coerceIn(0, noteColors.lastIndex)]
                Card(
                    onClick = { editing = n }, shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = bg)
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text(n.text, fontSize = size.sp, lineHeight = (size * 1.3).sp, color = noteInk, fontWeight = FontWeight.Medium, maxLines = 8)
                        n.remindAt?.let { at ->
                            Spacer(Modifier.height(10.dp))
                            val past = at.isBefore(LocalDateTime.now())
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Alarm, null, tint = if (past) noteInk.copy(alpha = 0.5f) else SpendRed, modifier = Modifier.size(24.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    at.format(DateTimeFormatter.ofPattern("EEE d MMM, h:mm a")) + if (past) " (done)" else "",
                                    fontSize = (size * 0.6).sp, color = noteInk.copy(alpha = if (past) 0.5f else 0.9f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) NoteSheet(null, size) { adding = false }
    editing?.let { NoteSheet(it, size) { editing = null } }
}

@Composable
private fun NoteSheet(existing: Note?, size: Int, onDone: () -> Unit) {
    val context = LocalContext.current
    var text by remember { mutableStateOf(existing?.text ?: "") }
    var color by remember { mutableIntStateOf(existing?.color ?: 0) }
    var remindAt by remember { mutableStateOf(existing?.remindAt?.takeIf { it.isAfter(LocalDateTime.now()) }) }

    fun pickReminder() {
        val start = remindAt ?: LocalDateTime.now().plusHours(1).withMinute(0)
        DatePickerDialog(context, { _, y, m, d ->
            TimePickerDialog(context, { _, h, min ->
                remindAt = LocalDateTime.of(y, m + 1, d, h, min)
            }, start.hour, start.minute, false).show()
        }, start.year, start.monthValue - 1, start.dayOfMonth).apply { datePicker.minDate = System.currentTimeMillis() - 1000 }.show()
    }

    ModalBottomSheet(onDismissRequest = onDone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(if (existing == null) "New note" else "Edit note", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = text, onValueChange = { text = it.take(1000) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
                textStyle = TextStyle(fontSize = size.sp, lineHeight = (size * 1.3).sp, color = noteInk, fontWeight = FontWeight.Medium),
                placeholder = { Text("Write here…", fontSize = size.sp) },
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = noteColors[color], unfocusedContainerColor = noteColors[color]
                )
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                noteColors.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(c)
                            .border(if (color == i) 3.dp else 1.dp, if (color == i) noteInk else noteInk.copy(alpha = 0.2f), CircleShape)
                            .clickable { color = i }
                    )
                }
            }
            OutlinedButton(
                onClick = { pickReminder() }, modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Rounded.Alarm, null, Modifier.size(26.dp)); Spacer(Modifier.width(10.dp))
                Text(
                    remindAt?.let { "Remind: " + it.format(DateTimeFormatter.ofPattern("d MMM, h:mm a")) } ?: "Add reminder",
                    fontSize = 20.sp
                )
            }
            if (remindAt != null) TextButton(onClick = { remindAt = null }) { Text("Remove reminder", fontSize = 18.sp) }

            Button(
                onClick = {
                    val saved = Note.save(Note(existing?.id ?: 0, text.trim(), remindAt, existing?.created ?: System.currentTimeMillis(), color))
                    Reminders.scheduleNote(context, saved)
                    onDone()
                },
                enabled = text.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(64.dp), shape = RoundedCornerShape(18.dp)
            ) { Text("Save", fontSize = 22.sp) }

            if (existing != null) OutlinedButton(
                onClick = {
                    Reminders.cancel(context, Reminders.KIND_NOTE, existing.id)
                    Repository.deleteItem(existing.id); onDone()
                },
                modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, SpendRed)
            ) { Text("Delete note", color = SpendRed, fontSize = 18.sp) }
        }
    }
}
