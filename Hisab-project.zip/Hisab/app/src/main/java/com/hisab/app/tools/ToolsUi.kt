@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Repository

enum class Tool(val title: String, val subtitle: String, val icon: ImageVector, val color: Color, val section: String) {
    UDHAAR("Udhaar Book", "Who owes you, whom you owe", Icons.Rounded.Handshake, Color(0xFFE67E22), "Money"),
    BILLS("Bill Reminder", "Never miss a due date", Icons.Rounded.ReceiptLong, Color(0xFFD64545), "Money"),
    CALC("Calculator", "GST, EMI, discount, interest", Icons.Rounded.Calculate, Color(0xFF2F6FED), "Money"),
    MEDICINE("Medicine Reminder", "Alarm for every tablet", Icons.Rounded.Medication, Color(0xFF00A884), "Home & family"),
    ATTENDANCE("Milk & Maid", "Attendance and monthly bill", Icons.Rounded.CalendarMonth, Color(0xFF8E44AD), "Home & family"),
    GROCERY("Grocery List", "Quick add and share", Icons.Rounded.ShoppingCart, Color(0xFF27AE60), "Home & family"),
    LOCKER("Document Locker", "Aadhaar, PAN, licence, bills", Icons.Rounded.Lock, Color(0xFF34495E), "Personal"),
    NOTES("Big Notes", "Large text and reminders", Icons.Rounded.StickyNote2, Color(0xFFF39C12), "Personal")
}

/** List of items for a tool; re-reads automatically whenever anything is saved. */
@Composable
fun <T> rememberItems(loader: () -> List<T>): List<T> {
    val version by Repository.itemsVersion.collectAsState()
    return remember(version) { loader() }
}

@Composable
fun ToolsHub(modifier: Modifier, onOpen: (Tool) -> Unit) {
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Tools", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
        }
        Tool.entries.groupBy { it.section }.forEach { (section, tools) ->
            item(key = section) {
                Text(
                    section, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                )
            }
            tools.chunked(2).forEach { pair ->
                item(key = pair.first().name) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { t -> ToolCard(t, Modifier.weight(1f)) { onOpen(t) } }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolCard(t: Tool, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = modifier.height(132.dp), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(t.color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) { Icon(t.icon, null, tint = t.color) }
            Spacer(Modifier.weight(1f))
            Text(t.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                t.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Common frame for every tool: title bar with back arrow, optional add button. */
@Composable
fun ToolScaffold(
    title: String,
    onBack: () -> Unit,
    fabText: String? = null,
    onFab: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back") } },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            if (fabText != null && onFab != null) {
                ExtendedFloatingActionButton(
                    onClick = onFab, icon = { Icon(Icons.Rounded.Add, null) }, text = { Text(fabText) },
                    containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    ) { content(it) }
}

// ---------------------------------------------------------------- small shared inputs

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    number: Boolean = false, prefix: String? = null, suffix: String? = null, singleLine: Boolean = true,
    leading: ImageVector? = null, phone: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = { v ->
            if (!number || v.all { it.isDigit() || it == '.' }) onChange(v)
        },
        modifier = modifier,
        label = { Text(label) },
        prefix = prefix?.let { p -> @Composable { Text(p) } },
        suffix = suffix?.let { s -> @Composable { Text(s) } },
        leadingIcon = leading?.let { ic -> @Composable { Icon(ic, null) } },
        singleLine = singleLine,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(
            keyboardType = when {
                phone -> KeyboardType.Phone
                number -> KeyboardType.Decimal
                else -> KeyboardType.Text
            }
        )
    )
}

@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options.size) { i ->
            val o = options[i]
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) })
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, color: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = color)
    ) { Text(text, style = MaterialTheme.typography.titleMedium) }
}

@Composable
fun IconCircle(icon: ImageVector, color: Color, size: androidx.compose.ui.unit.Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = color, modifier = Modifier.size(size * 0.5f)) }
}

fun String.toAmount(): Double = replace(",", "").toDoubleOrNull() ?: 0.0

fun Double.plain(): String = if (this % 1.0 == 0.0) toLong().toString() else "%.2f".format(this)
