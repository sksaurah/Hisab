@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Mode
import com.hisab.app.data.Txn
import com.hisab.app.data.TxnType
import androidx.fragment.app.FragmentActivity
import com.hisab.app.tools.*

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    TXNS("History", Icons.Rounded.ReceiptLong),
    TOOLS("Tools", Icons.Rounded.Apps),
    STEPS("Steps", Icons.Rounded.DirectionsWalk),
    SETTINGS("Settings", Icons.Rounded.Settings)
}

/** What the add/edit sheet should open with. */
data class EditorRequest(val existing: Txn? = null, val type: TxnType = TxnType.DEBIT, val mode: Mode = Mode.CASH)

/** FragmentActivity (a ComponentActivity) so the fingerprint prompt works. */
class MainActivity : FragmentActivity() {

    /** Bumped every time the app comes back to the front, so permission states refresh. */
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HisabTheme { AppRoot(resumeTick.intValue) }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

@Composable
fun AppRoot(resumeTick: Int) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var editor by remember { mutableStateOf<EditorRequest?>(null) }
    var openTool by rememberSaveable { mutableStateOf<Tool?>(null) }

    // A tool opens full screen on top of the tabs
    openTool?.let { t ->
        BackHandler { openTool = null }
        val back = { openTool = null }
        when (t) {
            Tool.UDHAAR -> UdhaarScreen(back)
            Tool.BILLS -> BillsScreen(back)
            Tool.CALC -> CalculatorScreen(back)
            Tool.MEDICINE -> MedicineScreen(back)
            Tool.ATTENDANCE -> AttendanceScreen(back)
            Tool.GROCERY -> GroceryScreen(back)
            Tool.LOCKER -> LockerScreen(back)
            Tool.NOTES -> NotesScreen(back)
        }
        return
    }

    BackHandler(enabled = tab != Tab.HOME) { tab = Tab.HOME }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == Tab.HOME || tab == Tab.TXNS) {
                ExtendedFloatingActionButton(
                    onClick = { editor = EditorRequest() },
                    icon = { Icon(Icons.Rounded.Add, null) },
                    text = { Text("Add entry") },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    ) { padding ->
        val m = Modifier.padding(padding)
        when (tab) {
            Tab.HOME -> HomeScreen(
                modifier = m, resumeTick = resumeTick,
                onAdd = { editor = it },
                onOpen = { editor = EditorRequest(existing = it) },
                onSeeAll = { tab = Tab.TXNS },
                onSteps = { tab = Tab.STEPS },
                onSettings = { tab = Tab.SETTINGS }
            )
            Tab.TXNS -> TransactionsScreen(modifier = m, onOpen = { editor = EditorRequest(existing = it) })
            Tab.TOOLS -> ToolsHub(modifier = m, onOpen = { openTool = it })
            Tab.STEPS -> StepsScreen(modifier = m, resumeTick = resumeTick)
            Tab.SETTINGS -> SettingsScreen(modifier = m, resumeTick = resumeTick)
        }
    }

    editor?.let { req -> TxnEditorSheet(req, onDismiss = { editor = null }) }
}

