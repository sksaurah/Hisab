@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Repository
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard

@Composable
fun GroceryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val list = rememberItems { Grocery.all() }
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    val toBuy = list.filter { !it.done }
    val bought = list.filter { it.done }

    fun add(n: String, q: String = "") {
        val clean = n.trim()
        if (clean.isEmpty()) return
        val existing = list.firstOrNull { it.name.equals(clean, true) }
        if (existing != null) Grocery.save(existing.copy(done = false, qty = q.ifBlank { existing.qty }))
        else Grocery.save(Grocery(0, clean.replaceFirstChar { it.uppercase() }, q.trim()))
    }

    ToolScaffold(
        "Grocery List", onBack,
        actions = {
            if (toBuy.isNotEmpty()) IconButton(onClick = {
                val text = "🛒 Grocery list\n" + toBuy.joinToString("\n") { "• ${it.name}" + if (it.qty.isNotBlank()) " – ${it.qty}" else "" }
                context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share list"))
            }) { Icon(Icons.Rounded.Share, "Share") }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = name, onValueChange = { name = it.take(40) }, modifier = Modifier.weight(1.6f),
                            placeholder = { Text("Item") }, singleLine = true, shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { add(name, qty); name = ""; qty = "" })
                        )
                        OutlinedTextField(
                            value = qty, onValueChange = { qty = it.take(12) }, modifier = Modifier.weight(1f),
                            placeholder = { Text("Qty") }, singleLine = true, shape = RoundedCornerShape(14.dp)
                        )
                        FilledIconButton(onClick = { add(name, qty); name = ""; qty = "" }, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Rounded.Add, "Add")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Quick add", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    val names = toBuy.map { it.name.lowercase() }.toSet()
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(Grocery.COMMON.filter { it.lowercase() !in names }) { c ->
                            AssistChip(onClick = { add(c) }, label = { Text("+ $c") })
                        }
                    }
                }
            }

            if (list.isEmpty()) item {
                SectionCard { EmptyState(Icons.Rounded.ShoppingCart, "List is empty", "Type an item or tap a quick-add chip. Share the list on WhatsApp.") }
            }

            if (toBuy.isNotEmpty()) item {
                SectionCard(title = "To buy (${toBuy.size})") {
                    toBuy.forEach { g -> GroceryRow(g) }
                }
            }
            if (bought.isNotEmpty()) item {
                SectionCard(title = "Bought (${bought.size})", action = "Clear", onAction = { bought.forEach { Repository.deleteItem(it.id) } }) {
                    bought.forEach { g -> GroceryRow(g) }
                }
            }
        }
    }
}

@Composable
private fun GroceryRow(g: Grocery) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = g.done, onCheckedChange = { Grocery.save(g.copy(done = it)) })
        Column(Modifier.weight(1f)) {
            Text(
                g.name, style = MaterialTheme.typography.bodyLarge,
                textDecoration = if (g.done) TextDecoration.LineThrough else null,
                color = if (g.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            if (g.qty.isNotBlank()) Text(g.qty, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = { Repository.deleteItem(g.id) }) { Icon(Icons.Rounded.Close, "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
