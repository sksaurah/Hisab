@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.app.DatePickerDialog
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hisab.app.data.*
import com.hisab.app.ui.EarnGreen
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard
import com.hisab.app.ui.SpendRed
import com.hisab.app.ui.money
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val Purple = Color(0xFF8E44AD)

@Composable
fun AttendanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val services = rememberItems { Service.all() }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var editing by remember { mutableStateOf<Service?>(null) }
    var newPreset by remember { mutableStateOf<String?>(null) }
    var dayDialog by remember { mutableStateOf<LocalDate?>(null) }
    var confirmPay by remember { mutableStateOf(false) }
    val today = LocalDate.now()

    val svc = services.firstOrNull { it.id == selectedId } ?: services.firstOrNull()

    ToolScaffold(
        "Milk & Maid", onBack,
        actions = { if (svc != null) IconButton(onClick = { editing = svc }) { Icon(Icons.Rounded.Edit, "Edit") } }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(services, key = { it.id }) { s ->
                        FilterChip(selected = s.id == svc?.id, onClick = { selectedId = s.id }, label = { Text(s.name) })
                    }
                    item {
                        AssistChip(onClick = { newPreset = "" }, label = { Text("+ Add") }, leadingIcon = { Icon(Icons.Rounded.Add, null) })
                    }
                }
            }

            if (svc == null) {
                item {
                    SectionCard {
                        EmptyState(Icons.Rounded.CalendarMonth, "Track daily services", "Milkman, maid, cook, newspaper… Every day counts as present. Just tap the days they don't come.")
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { newPreset = "Milk" }, Modifier.weight(1f)) { Text("🥛 Add Milk") }
                            OutlinedButton(onClick = { newPreset = "Maid" }, Modifier.weight(1f)) { Text("🧹 Add Maid") }
                        }
                    }
                }
                return@LazyColumn
            }

            val bill = AttendanceLogic.bill(month, svc.perDay, svc.rate, svc.salary, svc.allowedLeaves, svc.start, today) { svc.qtyOn(it) }
            val paid = month.toString() in svc.paid

            // Month switcher
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Rounded.ChevronLeft, "Previous") }
                    Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    IconButton(onClick = { month = month.plusMonths(1) }, enabled = month < YearMonth.now()) { Icon(Icons.Rounded.ChevronRight, "Next") }
                }
            }

            // Calendar
            item {
                SectionCard {
                    CalendarGrid(month, today, svc) { d -> if (!d.isAfter(today) && !d.isBefore(svc.start)) dayDialog = d }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Legend(EarnGreen, "Came"); Legend(SpendRed, "Absent"); if (svc.perDay) Legend(Purple, "Extra / less")
                    }
                    Text(
                        "Tap a day to change it.", style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }

            // Bill
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Purple.copy(alpha = 0.09f))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${month.format(DateTimeFormatter.ofPattern("MMMM"))} bill", style = MaterialTheme.typography.labelLarge, color = Purple)
                        Text(money(bill.amount), style = MaterialTheme.typography.headlineMedium)
                        if (svc.perDay) {
                            Text("${bill.totalQty.plain()} ${svc.unit} × ${money(svc.rate)}", style = MaterialTheme.typography.bodyLarge)
                            Text("Came ${bill.daysCame} days · absent ${bill.absents}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Text("Salary ${money(svc.salary)} · absent ${bill.absents} (allowed ${svc.allowedLeaves})", style = MaterialTheme.typography.bodyLarge)
                            val extra = maxOf(0, bill.absents - svc.allowedLeaves)
                            if (extra > 0) Text("$extra extra leave${if (extra > 1) "s" else ""} deducted", style = MaterialTheme.typography.bodyMedium, color = SpendRed)
                            if (month == YearMonth.now()) Text("Counted till today (${bill.daysCounted} days)", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = {
                                val text = buildString {
                                    append("${svc.name} bill – ${month.format(DateTimeFormatter.ofPattern("MMMM yyyy"))}\n")
                                    if (svc.perDay) append("${bill.totalQty.plain()} ${svc.unit} × ${money(svc.rate)}\nAbsent days: ${bill.absents}\n")
                                    else append("Salary ${money(svc.salary)}\nAbsent days: ${bill.absents} (allowed ${svc.allowedLeaves})\n")
                                    append("Total: ${money(bill.amount)}")
                                }
                                context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share bill"))
                            }, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Rounded.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Share") }
                            if (paid) {
                                OutlinedButton(onClick = { Service.save(svc.copy(paid = svc.paid - month.toString())) }, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                                    Icon(Icons.Rounded.CheckCircle, null, Modifier.size(18.dp), tint = EarnGreen); Spacer(Modifier.width(6.dp)); Text("Paid")
                                }
                            } else {
                                Button(onClick = { confirmPay = true }, Modifier.weight(1f), shape = RoundedCornerShape(12.dp), enabled = bill.amount > 0) { Text("Mark paid") }
                            }
                        }
                    }
                }
            }
        }
    }

    // Day editor
    dayDialog?.let { d ->
        val s = svc ?: return@let
        DayDialog(s, d) { dayDialog = null }
    }

    if (confirmPay && svc != null) {
        val bill = AttendanceLogic.bill(month, svc.perDay, svc.rate, svc.salary, svc.allowedLeaves, svc.start, today) { svc.qtyOn(it) }
        var addExpense by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { confirmPay = false },
            title = { Text("Paid ${money(bill.amount)} to ${svc.name}?") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = addExpense, onCheckedChange = { addExpense = it }); Text("Also add to my expenses")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    Service.save(svc.copy(paid = svc.paid + month.toString()))
                    if (addExpense) Repository.save(
                        Txn(
                            amount = bill.amount, type = TxnType.DEBIT, mode = Mode.CASH,
                            category = if (svc.perDay && svc.name.contains("milk", true)) Category.MILK else Category.RENT,
                            party = svc.name, note = "${month.format(DateTimeFormatter.ofPattern("MMMM"))} bill", source = Source.MANUAL,
                            time = LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        )
                    )
                    confirmPay = false
                }) { Text("Paid") }
            },
            dismissButton = { TextButton(onClick = { confirmPay = false }) { Text("Cancel") } }
        )
    }

    newPreset?.let { preset ->
        val base = when (preset) {
            "Milk" -> Service(0, "Milk", true, 1.0, "L", 60.0, 0.0, 0, LocalDate.now().withDayOfMonth(1))
            "Maid" -> Service(0, "Maid", false, 1.0, "", 0.0, 3000.0, 2, LocalDate.now().withDayOfMonth(1))
            else -> Service(0, "", true, 1.0, "L", 0.0, 0.0, 0, LocalDate.now().withDayOfMonth(1))
        }
        ServiceSheet(base, isNew = true, onSaved = { selectedId = it }) { newPreset = null }
    }
    editing?.let { ServiceSheet(it, isNew = false, onSaved = {}) { editing = null } }
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun CalendarGrid(month: YearMonth, today: LocalDate, s: Service, onTap: (LocalDate) -> Unit) {
    val offset = month.atDay(1).dayOfWeek.value - 1      // Monday first
    val cells = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    Row(Modifier.fillMaxWidth()) {
        listOf("M", "T", "W", "T", "F", "S", "S").forEach {
            Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Spacer(Modifier.height(6.dp))
    cells.chunked(7).forEach { week ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            week.forEach { d ->
                Box(Modifier.weight(1f).aspectRatio(1f)) {
                    if (d != null) {
                        val future = d.isAfter(today)
                        val beforeStart = d.isBefore(s.start)
                        val q = s.qtyOn(d)
                        val bg = when {
                            future || beforeStart -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            q <= 0 -> SpendRed.copy(alpha = 0.18f)
                            s.perDay && q != s.qty -> Purple.copy(alpha = 0.18f)
                            else -> EarnGreen.copy(alpha = 0.16f)
                        }
                        Box(
                            Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).background(bg)
                                .then(if (d == today) Modifier.background(Color.Transparent) else Modifier)
                                .clickable(enabled = !future && !beforeStart) { onTap(d) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    d.dayOfMonth.toString(), fontSize = 14.sp,
                                    fontWeight = if (d == today) FontWeight.Bold else FontWeight.Normal,
                                    color = if (future || beforeStart) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface
                                )
                                if (!future && !beforeStart) {
                                    Text(
                                        when { q <= 0 -> "✗"; s.perDay && q != s.qty -> q.plain(); else -> "✓" },
                                        fontSize = 10.sp, color = when { q <= 0 -> SpendRed; s.perDay && q != s.qty -> Purple; else -> EarnGreen }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun DayDialog(s: Service, d: LocalDate, onDone: () -> Unit) {
    val current = s.qtyOn(d)
    var custom by remember { mutableStateOf("") }
    fun set(q: Double) {
        val key = d.toString()
        val default = if (s.perDay) s.qty else 1.0
        val ov = if (q == default) s.overrides - key else s.overrides + (key to q)
        Service.save(s.copy(overrides = ov))
        onDone()
    }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("${s.name} · ${d.format(DateTimeFormatter.ofPattern("EEE, d MMM"))}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (s.perDay) {
                    Text("How much came? (now ${current.plain()} ${s.unit})")
                    val opts = listOf(0.0, 0.5, 1.0, 1.5, 2.0, 3.0)
                    opts.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { q ->
                                OutlinedButton(
                                    onClick = { set(q) }, Modifier.weight(1f),
                                    border = if (q == current) BorderStroke(2.dp, Purple) else ButtonDefaults.outlinedButtonBorder,
                                    contentPadding = PaddingValues(4.dp)
                                ) { Text(if (q == 0.0) "Absent" else "${q.plain()} ${s.unit}") }
                            }
                        }
                    }
                    Field(custom, { custom = it.take(5) }, "Other quantity", number = true, suffix = s.unit)
                } else {
                    Text(if (current > 0) "Marked present" else "Marked absent")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ToggleBox("Came", "Present", EarnGreen, current > 0, Modifier.weight(1f)) { set(1.0) }
                        ToggleBox("Absent", "Leave", SpendRed, current <= 0, Modifier.weight(1f)) { set(0.0) }
                    }
                }
            }
        },
        confirmButton = {
            if (s.perDay && custom.isNotBlank()) TextButton(onClick = { set(custom.toAmount()) }) { Text("Save") }
            else TextButton(onClick = onDone) { Text("Close") }
        }
    )
}

@Composable
private fun ServiceSheet(base: Service, isNew: Boolean, onSaved: (Long) -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(base.name) }
    var perDay by remember { mutableStateOf(base.perDay) }
    var qty by remember { mutableStateOf(base.qty.plain()) }
    var unit by remember { mutableStateOf(base.unit) }
    var rate by remember { mutableStateOf(if (base.rate > 0) base.rate.plain() else "") }
    var salary by remember { mutableStateOf(if (base.salary > 0) base.salary.plain() else "") }
    var leaves by remember { mutableStateOf(base.allowedLeaves.toString()) }
    var start by remember { mutableStateOf(base.start) }
    var confirmDelete by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (isNew) "New service" else "Edit ${base.name}", style = MaterialTheme.typography.titleLarge)
            Field(name, { name = it.take(30) }, "Name (Milk, Maid, Cook, Newspaper…)")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToggleBox("Per day", "Milk, newspaper", Purple, perDay, Modifier.weight(1f)) { perDay = true }
                ToggleBox("Monthly salary", "Maid, cook, driver", Purple, !perDay, Modifier.weight(1f)) { perDay = false }
            }
            if (perDay) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Field(qty, { qty = it.take(5) }, "Daily qty", Modifier.weight(1f), number = true)
                    Field(unit, { unit = it.take(8) }, "Unit (L, pkt)", Modifier.weight(1f))
                }
                Field(rate, { rate = it.take(7) }, "Price per ${unit.ifBlank { "unit" }}", number = true, prefix = "₹ ")
            } else {
                Field(salary, { salary = it.take(8) }, "Monthly salary", number = true, prefix = "₹ ")
                Field(leaves, { v -> if (v.length <= 2 && v.all { it.isDigit() }) leaves = v }, "Leaves allowed per month", number = true)
            }
            OutlinedButton(
                onClick = { DatePickerDialog(context, { _, y, m, d -> start = LocalDate.of(y, m + 1, d) }, start.year, start.monthValue - 1, start.dayOfMonth).show() },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)
            ) { Text("Started on " + start.format(DateTimeFormatter.ofPattern("d MMM yyyy"))) }

            PrimaryButton("Save", enabled = name.isNotBlank() && (if (perDay) rate.toAmount() > 0 && qty.toAmount() > 0 else salary.toAmount() > 0)) {
                val saved = Service.save(
                    base.copy(
                        name = name.trim(), perDay = perDay, qty = qty.toAmount().takeIf { it > 0 } ?: 1.0, unit = unit.trim(),
                        rate = rate.toAmount(), salary = salary.toAmount(), allowedLeaves = leaves.toIntOrNull() ?: 0, start = start
                    )
                )
                onSaved(saved.id)
                onDone()
            }
            if (!isNew) TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete ${base.name}", color = SpendRed) }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${base.name}?") },
        text = { Text("All attendance for ${base.name} will be removed.") },
        confirmButton = { TextButton(onClick = { Repository.deleteItem(base.id); confirmDelete = false; onDone() }) { Text("Delete", color = SpendRed) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}
