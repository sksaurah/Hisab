package com.hisab.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Brand = Color(0xFF1B5E4B)
val BrandDark = Color(0xFF0F3D31)
val SpendRed = Color(0xFFD64545)
val EarnGreen = Color(0xFF1E9E6A)
val StepBlue = Color(0xFF2F6FED)

private val Light = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3EFE4),
    onPrimaryContainer = BrandDark,
    secondary = Color(0xFF4C6358),
    secondaryContainer = Color(0xFFE3ECE7),
    tertiary = StepBlue,
    background = Color(0xFFF6F8F7),
    surface = Color.White,
    surfaceVariant = Color(0xFFEEF2F0),
    onSurfaceVariant = Color(0xFF5B6662),
    outlineVariant = Color(0xFFDCE3E0)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF7DD6B5),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF1F4F41),
    onPrimaryContainer = Color(0xFFC9F1E1),
    secondary = Color(0xFFB2CCC0),
    secondaryContainer = Color(0xFF2D3A35),
    tertiary = Color(0xFF9DB9FF),
    background = Color(0xFF0E1412),
    surface = Color(0xFF151C19),
    surfaceVariant = Color(0xFF1E2724),
    onSurfaceVariant = Color(0xFFA9B6B1),
    outlineVariant = Color(0xFF2E3935)
)

private val AppTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp)
)

@Composable
fun HisabTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = AppTypography,
        content = content
    )
}
