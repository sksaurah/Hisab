package com.hisab.app.tools

import com.hisab.app.data.Repository
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth

// Small helpers for JSON <-> lists
private fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else (0 until length()).map { getString(it) }
private fun List<String>.toJsonArray() = JSONArray().also { a -> forEach { a.put(it) } }

// ======================================================================== Udhaar (lend / borrow)

data class Udhaar(
    val id: Long = 0,
    val person: String,
    val phone: String,
    val amount: Double,
    /** true = they owe me (I gave), false = I owe them (I took) */
    val theyOwe: Boolean,
    val note: String,
    val date: LocalDate,
    val settled: Boolean = false
) {
    fun toJson() = JSONObject().put("person", person).put("phone", phone).put("amount", amount)
        .put("theyOwe", theyOwe).put("note", note).put("date", date.toString()).put("settled", settled)

    companion object {
        const val KIND = "udhaar"
        private fun from(id: Long, j: JSONObject) = Udhaar(
            id, j.optString("person"), j.optString("phone"), j.optDouble("amount", 0.0), j.optBoolean("theyOwe", true),
            j.optString("note"), runCatching { LocalDate.parse(j.optString("date")) }.getOrDefault(LocalDate.now()),
            j.optBoolean("settled", false)
        )
        fun all() = Repository.items(KIND).map { from(it.first, it.second) }
        fun save(u: Udhaar) = Repository.saveItem(KIND, u.id, u.toJson())
    }
}

// ======================================================================== Bills

data class Bill(
    val id: Long = 0,
    val name: String,
    val type: String,
    val amount: Double,
    val dueDay: Int,
    val remindBefore: Int,
    val paid: Set<String> = emptySet()      // months paid, e.g. "2026-11"
) {
    fun dueDate(month: YearMonth): LocalDate = month.atDay(minOf(dueDay, month.lengthOfMonth()))
    fun isPaid(month: YearMonth) = month.toString() in paid
    fun nextAlert(now: LocalDateTime): LocalDateTime? = BillLogic.nextAlert(dueDay, remindBefore, paid, now)

    fun toJson() = JSONObject().put("name", name).put("type", type).put("amount", amount).put("dueDay", dueDay)
        .put("remindBefore", remindBefore).put("paid", paid.toList().toJsonArray())

    companion object {
        const val KIND = "bill"
        val TYPES = listOf("Electricity", "Mobile", "Internet", "EMI", "Rent", "Gas", "Water", "Insurance", "School fees", "Other")
        private fun from(id: Long, j: JSONObject) = Bill(
            id, j.optString("name"), j.optString("type", "Other"), j.optDouble("amount", 0.0),
            j.optInt("dueDay", 1), j.optInt("remindBefore", 2), j.optJSONArray("paid").strings().toSet()
        )
        fun all() = Repository.items(KIND).map { from(it.first, it.second) }
        fun load(id: Long) = Repository.item(id)?.let { from(id, it) }
        fun save(b: Bill): Bill = b.copy(id = Repository.saveItem(KIND, b.id, b.toJson()))
    }
}

// ======================================================================== Medicine

data class Medicine(
    val id: Long = 0,
    val name: String,
    val dose: String,
    val times: List<LocalTime>,
    val enabled: Boolean = true,
    val taken: Map<String, Set<Int>> = emptyMap()   // "2026-11-27" -> slots taken
) {
    fun isTaken(date: LocalDate, slot: Int) = taken[date.toString()]?.contains(slot) == true

    fun toJson(): JSONObject {
        val t = JSONObject()
        taken.forEach { (d, s) -> t.put(d, JSONArray(s.toList())) }
        return JSONObject().put("name", name).put("dose", dose)
            .put("times", times.map { it.toString() }.toJsonArray()).put("enabled", enabled).put("taken", t)
    }

    companion object {
        const val KIND = "medicine"
        private fun from(id: Long, j: JSONObject): Medicine {
            val t = j.optJSONObject("taken")
            val taken = mutableMapOf<String, Set<Int>>()
            t?.keys()?.forEach { k ->
                val a = t.optJSONArray(k)
                if (a != null) taken[k] = (0 until a.length()).map { a.getInt(it) }.toSet()
            }
            return Medicine(
                id, j.optString("name"), j.optString("dose"),
                j.optJSONArray("times").strings().mapNotNull { runCatching { LocalTime.parse(it) }.getOrNull() }.sorted(),
                j.optBoolean("enabled", true), taken
            )
        }
        fun all() = Repository.items(KIND).map { from(it.first, it.second) }
        fun load(id: Long) = Repository.item(id)?.let { from(id, it) }
        fun save(m: Medicine): Medicine = m.copy(id = Repository.saveItem(KIND, m.id, m.toJson()))

        fun markTaken(m: Medicine, date: LocalDate, slot: Int, value: Boolean) {
            val key = date.toString()
            val set = (m.taken[key] ?: emptySet()).let { if (value) it + slot else it - slot }
            // keep only the last 30 days of history
            val cutoff = LocalDate.now().minusDays(30).toString()
            val newTaken = (m.taken + (key to set)).filterKeys { it >= cutoff }
            save(m.copy(taken = newTaken))
        }
    }
}

// ======================================================================== Milk & maid attendance

data class Service(
    val id: Long = 0,
    val name: String,
    /** PER_DAY = paid per unit (milk, newspaper); MONTHLY = fixed salary (maid, cook, driver) */
    val perDay: Boolean,
    val qty: Double,              // default quantity per day (litres / packets)
    val unit: String,
    val rate: Double,             // price per unit
    val salary: Double,           // monthly salary
    val allowedLeaves: Int,
    val start: LocalDate,
    val overrides: Map<String, Double> = emptyMap(),   // date -> qty (0 = absent / didn't come)
    val paid: Set<String> = emptySet()
) {
    fun qtyOn(d: LocalDate): Double = overrides[d.toString()] ?: if (perDay) qty else 1.0
    fun cameOn(d: LocalDate) = qtyOn(d) > 0

    fun toJson(): JSONObject {
        val o = JSONObject(); overrides.forEach { (k, v) -> o.put(k, v) }
        return JSONObject().put("name", name).put("perDay", perDay).put("qty", qty).put("unit", unit)
            .put("rate", rate).put("salary", salary).put("allowedLeaves", allowedLeaves).put("start", start.toString())
            .put("overrides", o).put("paid", paid.toList().toJsonArray())
    }

    companion object {
        const val KIND = "service"
        private fun from(id: Long, j: JSONObject): Service {
            val o = j.optJSONObject("overrides")
            val ov = mutableMapOf<String, Double>()
            o?.keys()?.forEach { k -> ov[k] = o.optDouble(k, 0.0) }
            return Service(
                id, j.optString("name"), j.optBoolean("perDay", true), j.optDouble("qty", 1.0), j.optString("unit", "L"),
                j.optDouble("rate", 0.0), j.optDouble("salary", 0.0), j.optInt("allowedLeaves", 0),
                runCatching { LocalDate.parse(j.optString("start")) }.getOrDefault(LocalDate.now()),
                ov, j.optJSONArray("paid").strings().toSet()
            )
        }
        fun all() = Repository.items(KIND).map { from(it.first, it.second) }
        fun save(s: Service): Service = s.copy(id = Repository.saveItem(KIND, s.id, s.toJson()))
    }
}

// ======================================================================== Grocery

data class Grocery(val id: Long = 0, val name: String, val qty: String, val done: Boolean = false) {
    fun toJson() = JSONObject().put("name", name).put("qty", qty).put("done", done)

    companion object {
        const val KIND = "grocery"
        val COMMON = listOf(
            "Milk", "Bread", "Eggs", "Rice", "Atta", "Dal", "Sugar", "Salt", "Oil", "Tea", "Coffee", "Ghee",
            "Onion", "Tomato", "Potato", "Green chilli", "Ginger", "Garlic", "Lemon", "Coriander",
            "Curd", "Paneer", "Butter", "Biscuits", "Soap", "Detergent", "Toothpaste", "Shampoo", "Dishwash"
        )
        fun all() = Repository.items(KIND).map { (id, j) -> Grocery(id, j.optString("name"), j.optString("qty"), j.optBoolean("done")) }
        fun save(g: Grocery) = Repository.saveItem(KIND, g.id, g.toJson())
    }
}

// ======================================================================== Notes

data class Note(
    val id: Long = 0,
    val text: String,
    val remindAt: LocalDateTime? = null,
    val created: Long = System.currentTimeMillis(),
    val color: Int = 0
) {
    fun toJson() = JSONObject().put("text", text).put("remindAt", remindAt?.toString() ?: "")
        .put("created", created).put("color", color)

    companion object {
        const val KIND = "note"
        private fun from(id: Long, j: JSONObject) = Note(
            id, j.optString("text"),
            j.optString("remindAt").takeIf { it.isNotBlank() }?.let { runCatching { LocalDateTime.parse(it) }.getOrNull() },
            j.optLong("created", 0), j.optInt("color", 0)
        )
        fun all() = Repository.items(KIND).map { from(it.first, it.second) }
        fun load(id: Long) = Repository.item(id)?.let { from(id, it) }
        fun save(n: Note): Note = n.copy(id = Repository.saveItem(KIND, n.id, n.toJson()))
    }
}

// ======================================================================== Documents

data class Doc(val id: Long = 0, val title: String, val category: String, val file: String, val added: Long) {
    fun toJson() = JSONObject().put("title", title).put("category", category).put("file", file).put("added", added)

    companion object {
        const val KIND = "doc"
        val CATEGORIES = listOf("Aadhaar", "PAN", "Licence", "Voter ID", "Passport", "Bills", "Medical", "Property", "Other")
        fun all() = Repository.items(KIND).map { (id, j) ->
            Doc(id, j.optString("title"), j.optString("category", "Other"), j.optString("file"), j.optLong("added"))
        }
        fun save(d: Doc) = Repository.saveItem(KIND, d.id, d.toJson())
    }
}
