package com.hisab.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Small settings stored in SharedPreferences, observable from the UI. */
object Prefs {
    private const val FILE = "hisab_prefs"

    private val _stepGoal = MutableStateFlow(10000)
    val stepGoal: StateFlow<Int> = _stepGoal
    private val _strideCm = MutableStateFlow(76)
    val strideCm: StateFlow<Int> = _strideCm
    private val _autoCapture = MutableStateFlow(true)
    val autoCapture: StateFlow<Boolean> = _autoCapture

    fun init(context: Context) {
        val p = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        _stepGoal.value = p.getInt("goal", 10000)
        _strideCm.value = p.getInt("stride", 76)
        _autoCapture.value = p.getBoolean("auto", true)
    }

    fun setStepGoal(context: Context, v: Int) {
        _stepGoal.value = v.coerceIn(1000, 50000)
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("goal", _stepGoal.value).apply()
    }

    fun setStride(context: Context, v: Int) {
        _strideCm.value = v.coerceIn(40, 120)
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("stride", _strideCm.value).apply()
    }

    fun setAutoCapture(context: Context, v: Boolean) {
        _autoCapture.value = v
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("auto", v).apply()
    }

    // Step counter bookkeeping
    fun lastCounter(context: Context): Long =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getLong("lastCounter", -1L)

    fun setLastCounter(context: Context, v: Long) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putLong("lastCounter", v).apply()
}
