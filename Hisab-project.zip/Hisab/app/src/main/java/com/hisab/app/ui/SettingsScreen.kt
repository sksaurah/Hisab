@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.hisab.app.capture.SmsImporter
import com.hisab.app.data.Prefs
import com.hisab.app.data.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun SettingsScreen(modifier: Modifier, resumeTick: Int) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val auto by Prefs.autoCapture.collectAsState()
    val goal by Prefs.stepGoal.collectAsState()
    val stride by Prefs.strideCm.collectAsState()

    var refresh by remember { mutableIntStateOf(0) }
    val notif = remember(resumeTick, refresh) { Permissions.notificationAccess(context) }
    val sms = remember(resumeTick, refresh) { Permissions.sms(context) }
    val activity = remember(resumeTick, refresh) { Permissions.activity(context) }
    val battery = remember(resumeTick, refresh) { Permissions.batteryFree(context) }
    var importing by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { w ->
                        w.write("Date,Time,Type,Amount,Mode,Category,Name,Note,Source\n")
                        val dFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd")
                        val tFmt = DateTimeFormatter.ofPattern("HH:mm")
                        Repository.txns.value.sortedBy { it.time }.forEach { t ->
                            val dt = Instant.ofEpochMilli(t.time).atZone(ZoneId.systemDefault())
                            fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
                            w.write(listOf(
                                dt.format(dFmt), dt.format(tFmt),
                                if (t.type == com.hisab.app.data.TxnType.DEBIT) "Spent" else "Received",
                                t.amount.toString(), t.mode.label, q(t.category.label), q(t.party), q(t.note),
                                if (t.isAuto) "Auto" else "Manual"
                            ).joinToString(",") + "\n")
                        }
                    }
                }.isSuccess
            }
            Toast.makeText(context, if (ok) "Exported" else "Export failed", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
        }

        // ---- Auto capture
        item {
            SectionCard(title = "Auto-capture payments") {
                SettingRow(Icons.Rounded.AutoAwesome, "Auto-capture", "Record payments without typing") {
                    Switch(checked = auto, onCheckedChange = { Prefs.setAutoCapture(context, it) })
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingRow(
                    Icons.Rounded.Notifications, "Notification access",
                    "Reads GPay, PhonePe, Paytm & bank SMS alerts", onClick = { Permissions.openNotificationAccess(context) }
                ) { StatusChip(notif) }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingRow(
                    Icons.Rounded.Sms, "Bank SMS", "Catch bank SMS even if notifications are hidden",
                    onClick = { if (!sms) permLauncher.launch(Permissions.smsPerms) }
                ) { StatusChip(sms) }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingRow(
                    Icons.Rounded.Download, "Import past SMS", "Add payments from the last 90 days",
                    onClick = {
                        if (!sms) permLauncher.launch(Permissions.smsPerms)
                        else if (!importing) scope.launch {
                            importing = true
                            val n = withContext(Dispatchers.IO) { runCatching { SmsImporter.importRecent(context) }.getOrDefault(-1) }
                            importing = false
                            Toast.makeText(
                                context, if (n >= 0) "$n payments imported" else "Import failed", Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                ) {
                    if (importing) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                    else Icon(Icons.Rounded.ChevronRight, null)
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Info, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Seeing “Restricted setting”?", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Android blocks these permissions for apps installed from a file. " +
                            "Open App info → tap ⋮ (top right) → “Allow restricted settings”, then come back and turn them on.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { Permissions.openAppInfo(context) }, shape = RoundedCornerShape(12.dp)) { Text("Open App info") }
                }
            }
        }

        // ---- Steps
        item {
            SectionCard(title = "Steps") {
                SettingRow(
                    Icons.Rounded.DirectionsWalk, "Physical activity", "Needed to count steps",
                    onClick = { if (!activity) permLauncher.launch(Permissions.activityPerms) }
                ) { StatusChip(activity) }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingRow(Icons.Rounded.Flag, "Daily goal", "${groupThousands(goal)} steps") {
                    Stepper({ Prefs.setStepGoal(context, goal - 1000) }, { Prefs.setStepGoal(context, goal + 1000) })
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingRow(Icons.Rounded.Straighten, "Step length", "$stride cm (for distance)") {
                    Stepper({ Prefs.setStride(context, stride - 2) }, { Prefs.setStride(context, stride + 2) })
                }
            }
        }

        // ---- Background
        item {
            SectionCard(title = "Keep it running") {
                SettingRow(
                    Icons.Rounded.BatteryChargingFull, "Battery: don't optimize",
                    "Stops OnePlus/Android from closing Hisab in the background",
                    onClick = { Permissions.openBattery(context) }
                ) { StatusChip(battery) }
            }
        }

        // ---- Data
        item {
            SectionCard(title = "Your data") {
                SettingRow(Icons.Rounded.FileDownload, "Export to Excel (CSV)", "Save all entries as a file", onClick = {
                    exportLauncher.launch("Hisab-${java.time.LocalDate.now()}.csv")
                }) { Icon(Icons.Rounded.ChevronRight, null) }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingRow(Icons.Rounded.DeleteForever, "Delete all data", "Remove every entry and step record", onClick = {
                    confirmWipe = true
                }) { Icon(Icons.Rounded.ChevronRight, null) }
            }
        }
        item {
            Text(
                "Hisab 1.0 · All your data stays only on this phone. No login, no internet needed.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Delete all data?") },
            text = { Text("All entries, step history, tools data and locker documents will be removed. This can't be undone. Export first if you want a copy.") },
            confirmButton = {
                TextButton(onClick = { Repository.deleteAll(); java.io.File(context.filesDir, "locker").deleteRecursively(); confirmWipe = false }) { Text("Delete", color = SpendRed) }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingRow(
    icon: ImageVector, title: String, subtitle: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        trailing()
    }
}

@Composable
private fun StatusChip(on: Boolean) {
    val color = if (on) EarnGreen else MaterialTheme.colorScheme.primary
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.12f)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (on) Icons.Rounded.CheckCircle else Icons.Rounded.ToggleOff, null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(if (on) "On" else "Turn on", style = MaterialTheme.typography.labelMedium, color = color)
        }
    }
}

@Composable
private fun Stepper(onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = onMinus, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.Remove, "Less") }
        Spacer(Modifier.width(6.dp))
        FilledTonalIconButton(onClick = onPlus, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.Add, "More") }
    }
}
