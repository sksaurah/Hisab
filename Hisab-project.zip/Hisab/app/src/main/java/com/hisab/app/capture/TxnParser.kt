package com.hisab.app.capture

import com.hisab.app.data.Category
import com.hisab.app.data.Mode
import com.hisab.app.data.TxnType

data class ParsedTxn(
    val amount: Double,
    val type: TxnType,
    val party: String,
    val mode: Mode,
    val category: Category
)

/**
 * Reads UPI-app notifications and bank SMS and turns them into transactions.
 * Works with common Indian formats (SBI, HDFC, ICICI, Axis, Kotak, PNB, BoB,
 * GPay, PhonePe, Paytm, BHIM). Messages that are not real money movement
 * (OTP, offers, payment requests, due reminders, failed payments) are ignored.
 */
object TxnParser {

    private val amountRx = Regex("""(?:₹|\brs\.?|\binr)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)

    private val ignoreWords = listOf(
        "otp", "one time password", "verification code", "requested", "request for", "collect request",
        "is due", "due on", "due date", "reminder", "will be debited", "will be deducted", "failed",
        "declined", "unsuccessful", "not successful", "could not", "offer", "cashback upto", "cashback up to",
        "win ", "pre-approved", "preapproved", "loan of", "minimum amount", "min amt", "emi of", "bill of",
        "bill generated", "statement", "mandate", "autopay set", "e-mandate", "insufficient", "voucher",
        "coupon", "expire", "has requested", "pay now", "apply now", "limit increased"
    )

    private val creditPhrases = listOf("paid you", "sent you", "you received", "received from", "received rs",
        "received inr", "received ₹", "credited", "deposited", "refund", "reversed", "added to your", "cr.", " cr ")
    private val debitPhrases = listOf("debited", "spent", "paid", "sent", "withdrawn", "withdrawal", "purchase",
        "transferred to", "transfer to", "payment of", "txn of", "dr.", " dr ", "deducted", "used at", "used for")

    fun parse(rawText: String, fromUpiApp: Boolean = false): ParsedTxn? {
        val text = rawText.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        val lower = text.lowercase()
        if (ignoreWords.any { lower.contains(it) }) return null

        val amount = findAmount(text) ?: return null
        if (amount <= 0 || amount > 10_000_000) return null

        val type = detectType(lower) ?: return null
        val isAtm = lower.contains("atm") || (lower.contains("withdrawn") && !lower.contains("upi"))
        val mode = when {
            isAtm -> Mode.BANK
            fromUpiApp || lower.contains("upi") || lower.contains("vpa") || lower.contains("@") -> Mode.UPI
            lower.contains("card") || lower.contains("pos ") -> Mode.CARD
            else -> Mode.BANK
        }
        val party = if (isAtm) "ATM withdrawal" else findParty(text, type)
        val category = if (isAtm) Category.ATM else Categorizer.guess("$party $lower", type)
        return ParsedTxn(amount, type, party, mode, category)
    }

    // SBI style without currency: "debited by 150.0", "credited with 500"
    private val bareAmountRx = Regex("""(?:debited|credited|deducted)\s+(?:by|with|for)\s+([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)

    /** First amount that is not an "available balance" or "limit" figure. */
    private fun findAmount(text: String): Double? {
        for (m in amountRx.findAll(text)) {
            val before = text.substring(maxOf(0, m.range.first - 22), m.range.first).lowercase()
            if (listOf("bal", "balance", "limit", "avl", "available").any { before.contains(it) }) continue
            val v = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            return v
        }
        return bareAmountRx.find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull()
    }

    /** Whichever money word appears first decides: "debited ... credited to beneficiary" = debit. */
    private fun detectType(lower: String): TxnType? {
        // "X paid you ₹200" / "X sent you" are credits even though they contain "paid"/"sent"
        if (lower.contains("paid you") || lower.contains("sent you") || lower.contains("you received")) return TxnType.CREDIT
        val c = creditPhrases.map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull()
        val d = debitPhrases.map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull()
        return when {
            c == null && d == null -> null
            c == null -> TxnType.DEBIT
            d == null -> TxnType.CREDIT
            d < c -> TxnType.DEBIT
            else -> TxnType.CREDIT
        }
    }

    private val stopWords = "on|ref|refno|upi|via|from|for|avl|bal|using|thru|through|txn|info|date|dated|at|to|is|has|by|with|a/c|ac|not|if|call|-|credited|debited"
    private val namePart = """([A-Za-z0-9@._&' ]{2,40}?)"""
    private val end = """(?=\s+(?:$stopWords)\b|\.(?:\s|$)|[,;:(]|\s*$)"""

    private val paidYouRx = Regex("""^(.{2,40}?)\s+(?:has\s+)?(?:paid|sent)\s+you""", RegexOption.IGNORE_CASE)
    private val toRx = Regex("""\b(?:to|at|towards)\s+(?:vpa\s+|merchant\s+)?$namePart$end""", RegexOption.IGNORE_CASE)
    private val fromRx = Regex("""\b(?:from|by)\s+(?:vpa\s+)?$namePart$end""", RegexOption.IGNORE_CASE)

    private fun findParty(text: String, type: TxnType): String {
        paidYouRx.find(text)?.let { return clean(it.groupValues[1]) ?: "Received" }
        val primary = if (type == TxnType.DEBIT) toRx else fromRx
        for (m in primary.findAll(text)) clean(m.groupValues[1])?.let { return it }
        return if (type == TxnType.DEBIT) "Payment" else "Received"
    }

    /** Rejects account numbers / bank words and tidies names (ramesh@okaxis -> Ramesh). */
    private fun clean(s: String): String? {
        var n = s.trim().trim('.', '-', ':')
        if (n.isEmpty()) return null
        val l = n.lowercase()
        if (l.startsWith("your ") || l.startsWith("a/c") || l.startsWith("ac ") || l.startsWith("acct") ||
            l.startsWith("account") || l.startsWith("xx") || l.startsWith("*") || l.matches(Regex("[x*\\d ]+")) ||
            l in setOf("you", "your", "beneficiary", "bank", "upi", "mobile", "card", "self", "the", "a", "an",
                "neft", "imps", "rtgs", "upi", "cash", "cheque", "chq", "date")
        ) return null
        if (n.contains('@')) n = n.substringBefore('@')
        n = n.replace(Regex("[._]"), " ").replace(Regex("\\d{4,}"), "").replace(Regex("\\s+"), " ").trim()
        if (n.length < 2) return null
        val allCaps = n.none { it.isLowerCase() }
        return n.split(' ').joinToString(" ") { w ->
            if (!allCaps && w.length <= 3 && w.all { it.isUpperCase() }) w else w.lowercase().replaceFirstChar { it.uppercase() }
        }.take(30)
    }
}

/** Guesses a category from shop / person name and message words. */
object Categorizer {
    private val rules = listOf(
        Category.FOOD to listOf("swiggy", "zomato", "restaurant", "hotel", "cafe", "dhaba", "pizza", "burger", "domino", "kfc", "mcdonald", "food", "bakery", "sweets", "chai", "tea"),
        Category.GROCERY to listOf("bigbasket", "blinkit", "zepto", "dmart", "grocery", "kirana", "store", "mart", "jiomart", "instamart", "reliance fresh", "more retail", "vegetable", "sabzi"),
        Category.MILK to listOf("milk", "dairy", "amul", "mother dairy", "nandini", "doodh"),
        Category.TRAVEL to listOf("uber", "ola", "rapido", "irctc", "railway", "metro", "bus", "redbus", "makemytrip", "goibibo", "indigo", "airline", "fastag", "toll", "auto"),
        Category.FUEL to listOf("petrol", "fuel", "diesel", "hpcl", "bpcl", "iocl", "indian oil", "bharat petroleum", "hp pay", "shell", "cng"),
        Category.BILLS to listOf("electricity", "bescom", "msedcl", "tneb", "bses", "water", "gas", "lpg", "indane", "broadband", "bill", "power"),
        Category.RECHARGE to listOf("recharge", "airtel", "jio", "vodafone", "vi ", "bsnl", "dth", "tata play", "dish tv"),
        Category.SHOPPING to listOf("amazon", "flipkart", "myntra", "meesho", "ajio", "nykaa", "shopping", "mall", "fashion"),
        Category.HEALTH to listOf("pharmacy", "medical", "chemist", "hospital", "clinic", "apollo", "medplus", "1mg", "pharmeasy", "netmeds", "doctor", "lab", "diagnostic"),
        Category.RENT to listOf("rent", "society", "maintenance", "landlord", "maid"),
        Category.EDUCATION to listOf("school", "college", "fees", "tuition", "coaching", "university", "byju", "course"),
        Category.ENTERTAINMENT to listOf("netflix", "hotstar", "prime video", "spotify", "bookmyshow", "pvr", "inox", "youtube", "cinema"),
        Category.SALARY to listOf("salary", "sal ", "payroll", "wages"),
    )

    fun guess(text: String, type: TxnType): Category {
        val l = text.lowercase()
        for ((cat, words) in rules) if (words.any { l.contains(it) }) {
            if (cat == Category.SALARY && type == TxnType.DEBIT) continue
            return cat
        }
        return Category.OTHER
    }
}
