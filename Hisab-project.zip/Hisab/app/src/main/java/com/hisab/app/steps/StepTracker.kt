package com.hisab.app.steps

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.hisab.app.data.Prefs
import com.hisab.app.data.Repository
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.time.LocalDate
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * Uses the phone's built-in step counter chip (very low battery use).
 * The chip counts all steps since the phone was switched on; we read it every
 * 15 minutes in the background (and live while the Steps screen is open) and
 * add the difference to today's total.
 */
object StepTracker {

    fun hasSensor(context: Context): Boolean =
        (context.getSystemService(Context.SENSOR_SERVICE) as SensorManager)
            .getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null

    @Synchronized
    fun record(context: Context, counter: Long) {
        val last = Prefs.lastCounter(context)
        Prefs.setLastCounter(context, counter)
        if (last < 0) return                       // first reading: just remember it
        var delta = counter - last
        if (delta < 0) delta = counter             // phone restarted: chip reset to 0
        if (delta in 1..60000) Repository.addSteps(LocalDate.now(), delta.toInt())
    }

    /** Reads the current counter once (waits up to 5 s). */
    suspend fun readOnce(context: Context): Long? {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return null
        return withTimeoutOrNull(5000) {
            suspendCancellableCoroutine { cont ->
                val listener = object : SensorEventListener {
                    override fun onSensorChanged(e: SensorEvent) {
                        sm.unregisterListener(this)
                        if (cont.isActive) cont.resume(e.values[0].toLong())
                    }
                    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
                }
                sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
                cont.invokeOnCancellation { sm.unregisterListener(listener) }
            }
        }
    }

    fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<StepWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork("steps", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun distanceKm(steps: Int, strideCm: Int) = steps * strideCm / 100_000.0
    fun calories(steps: Int) = (steps * 0.04).toInt()
}

class StepWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Repository.init(applicationContext)
        StepTracker.readOnce(applicationContext)?.let { StepTracker.record(applicationContext, it) }
        return Result.success()
    }
}
