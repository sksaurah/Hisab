@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Repository
import com.hisab.app.ui.EarnGreen
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard
import com.hisab.app.ui.SpendRed
import java.time.LocalDate
import java.time.LocalTime

private val MedGreen = androidx.compose.ui.graphics.Color(0xFF00A884)

@Composable
fun MedicineScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val meds = rememberItems { Medicine.all() }
    var editing by remember { mutableStateOf<Medicine?>(null) }
    var adding by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val now = LocalTime.now()

    // Today's doses in time order
    val doses = meds.filter { it.enabled }.flatMap { m -> m.times.mapIndexed { i, t -> Triple(m, i, t) } }.sortedBy { it.third }
    val takenCount = doses.count { (m, i, _) -> m.isTaken(today, i) }

    val exactAllowed = remember {
        Build.VERSION.SDK_INT < 31 || context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    ToolScaffold("Medicine Reminder", onBack, fabText = "Add medicine", onFab = { adding = true }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { NotificationPermissionCard() }
            if (!exactAllowed) item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Allow “Alarms & reminders” so medicine alarms ring on time", Modifier.weight(1f))
                        TextButton(onClick = {
                            if (Build.VERSION.SDK_INT >= 31) runCatching {
                                context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                            }
                        }) { Text("Allow") }
                    }
                }
            }
            if (doses.isNotEmpty()) item {
                SectionCard(title = "Today · $takenCount of ${doses.size} taken") {
                    doses.forEach { (m, slot, t) ->
                        val taken = m.isTaken(today, slot)
                        val missed = !taken && t.isBefore(now.minusMinutes(30))
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(t.label(), style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(88.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    m.name, style = MaterialTheme.typography.bodyLarge,
                                    textDecoration = if (taken) TextDecoration.LineThrough else null
                                )
                                Text(
                                    when { taken -> "Taken ✓"; missed -> "Missed?"; else -> m.dose.ifBlank { "Upcoming" } },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = when { taken -> EarnGreen; missed -> SpendRed; else -> MaterialTheme.colorScheme.onSurfaceVariant }
                                )
                            }
                            Checkbox(checked = taken, onCheckedChange = { Medicine.markTaken(m, today, slot, it) })
                        }
                    }
                }
            }
            if (meds.isEmpty()) item {
                SectionCard { EmptyState(Icons.Rounded.Medication, "No medicines yet", "Add a medicine and its times. An alarm will ring at each time.") }
            }
            if (meds.isNotEmpty()) item { Text("All medicines", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp)) }
            items(meds, key = { it.id }) { m ->
                Card(onClick = { editing = m }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Rounded.Medication, if (m.enabled) MedGreen else MaterialTheme.colorScheme.outline)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(m.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                (if (m.dose.isNotBlank()) m.dose + " · " else "") + m.times.joinToString(", ") { it.label() },
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = m.enabled, onCheckedChange = { on ->
                            val saved = Medicine.save(m.copy(enabled = on))
                            Reminders.scheduleMedicine(context, saved)
                        })
                    }
                }
            }
        }
    }

    if (adding) MedicineSheet(null) { adding = false }
    editing?.let { MedicineSheet(it) { editing = null } }
}

private fun androidx.compose.runtime.snapshots.SnapshotStateList<LocalTime>.sortInPlace() {
    val sorted = this.sorted()
    clear(); addAll(sorted)
}

@Composable
private fun MedicineSheet(existing: Medicine?, onDone: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var dose by remember { mutableStateOf(existing?.dose ?: "") }
    val times = remember { mutableStateListOf<LocalTime>().apply { addAll(existing?.times ?: listOf(LocalTime.of(9, 0))) } }

    ModalBottomSheet(onDismissRequest = onDone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (existing == null) "New medicine" else "Edit medicine", style = MaterialTheme.typography.titleLarge)
            Field(name, { name = it.take(40) }, "Medicine name", leading = Icons.Rounded.Medication)
            Field(dose, { dose = it.take(40) }, "Dose (e.g. 1 tablet after food)")
            Text("Quick times", style = MaterialTheme.typography.labelLarge)
            ChipRow(listOf("Morning 8 AM", "Afternoon 2 PM", "Evening 6 PM", "Night 9 PM"), "") { label ->
                val t = when (label) {
                    "Morning 8 AM" -> LocalTime.of(8, 0)
                    "Afternoon 2 PM" -> LocalTime.of(14, 0)
                    "Evening 6 PM" -> LocalTime.of(18, 0)
                    else -> LocalTime.of(21, 0)
                }
                if (t !in times && times.size < 10) { times.add(t); times.sortInPlace() }
            }
            Text("Alarm times", style = MaterialTheme.typography.labelLarge)
            times.toList().forEachIndexed { i, t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = {
                            TimePickerDialog(context, { _, h, m ->
                                times[i] = LocalTime.of(h, m); times.sortInPlace()
                            }, t.hour, t.minute, false).show()
                        },
                        modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)
                    ) { Icon(Icons.Rounded.Alarm, null); Spacer(Modifier.width(8.dp)); Text(t.label(), style = MaterialTheme.typography.titleMedium) }
                    if (times.size > 1) IconButton(onClick = { times.removeAt(i) }) { Icon(Icons.Rounded.Close, "Remove time") }
                }
            }
            if (times.size < 10) TextButton(onClick = {
                TimePickerDialog(context, { _, h, m ->
                    val nt = LocalTime.of(h, m)
                    if (nt !in times) { times.add(nt); times.sortInPlace() }
                }, 12, 0, false).show()
            }) { Text("+ Add another time") }

            PrimaryButton("Save", enabled = name.isNotBlank() && times.isNotEmpty()) {
                val saved = Medicine.save(
                    Medicine(existing?.id ?: 0, name.trim(), dose.trim(), times.toList().distinct().sorted(), existing?.enabled ?: true, existing?.taken ?: emptyMap())
                )
                Reminders.scheduleMedicine(context, saved)
                onDone()
            }
            if (existing != null) TextButton(onClick = {
                Reminders.cancel(context, Reminders.KIND_MED, existing.id, 10)
                Repository.deleteItem(existing.id); onDone()
            }, modifier = Modifier.fillMaxWidth()) { Text("Delete medicine", color = SpendRed) }
        }
    }
}
