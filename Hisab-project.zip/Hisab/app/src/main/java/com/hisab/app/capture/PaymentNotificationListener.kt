package com.hisab.app.capture

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.hisab.app.data.Prefs
import com.hisab.app.data.Repository
import com.hisab.app.data.Source

/**
 * Reads payment notifications from UPI apps and bank SMS notifications from
 * messaging apps. Only the apps listed below are read; everything else is ignored.
 */
class PaymentNotificationListener : NotificationListenerService() {

    companion object {
        val UPI_APPS = setOf(
            "com.google.android.apps.nbu.paisa.user", // Google Pay
            "com.phonepe.app",                        // PhonePe
            "net.one97.paytm",                        // Paytm
            "in.org.npci.upiapp",                     // BHIM
            "in.amazon.mShop.android.shopping",       // Amazon Pay
            "com.dreamplug.androidapp",               // CRED
            "com.mobikwik_new",                       // MobiKwik
            "money.super.payments",                   // super.money
            "com.sbi.upi", "com.sbi.lotusintouch",    // SBI apps
            "com.csam.icici.bank.imobile",            // iMobile
            "com.snapwork.hdfc",                      // HDFC
            "com.axis.mobile",                        // Axis
            "com.msf.kbank.mobile"                    // Kotak
        )
        val SMS_APPS = setOf(
            "com.google.android.apps.messaging",
            "com.android.mms", "com.oneplus.mms", "com.android.messaging",
            "com.samsung.android.messaging", "com.miui.mms"
        )
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val isUpi = pkg in UPI_APPS
        if (!isUpi && pkg !in SMS_APPS) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        Repository.init(applicationContext)
        Prefs.init(applicationContext)
        if (!Prefs.autoCapture.value) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (body.isBlank()) return

        // For UPI apps the title often holds the important part ("₹200 received")
        val text = if (isUpi) "$title $body" else body
        val parsed = TxnParser.parse(text, fromUpiApp = isUpi) ?: return
        Repository.addAuto(
            parsed, sbn.postTime,
            if (isUpi) Source.NOTIFICATION else Source.SMS,
            text.take(500)
        )
    }
}
