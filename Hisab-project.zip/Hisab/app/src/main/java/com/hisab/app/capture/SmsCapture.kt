package com.hisab.app.capture

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import com.hisab.app.data.Prefs
import com.hisab.app.data.Repository
import com.hisab.app.data.Source

/** Catches bank SMS the moment they arrive (needs the SMS permission). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        Repository.init(context)
        Prefs.init(context)
        if (!Prefs.autoCapture.value) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (parts.isEmpty()) return
        val body = parts.joinToString("") { it.messageBody ?: "" }
        val time = parts.first().timestampMillis
        val parsed = TxnParser.parse(body) ?: return
        Repository.addAuto(parsed, time, Source.SMS, body.take(500))
    }
}

/** One-time import of bank SMS already in the inbox. */
object SmsImporter {
    /** Returns how many transactions were added. Run off the main thread. */
    fun importRecent(context: Context, days: Int = 90): Int {
        val since = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000
        var added = 0
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("body", "date"),
            "date >= ?", arrayOf(since.toString()),
            "date ASC"
        ) ?: return 0
        cursor.use { c ->
            while (c.moveToNext()) {
                val body = c.getString(0) ?: continue
                val date = c.getLong(1)
                val parsed = TxnParser.parse(body) ?: continue
                if (Repository.addAuto(parsed, date, Source.SMS, body.take(500))) added++
            }
        }
        return added
    }
}
