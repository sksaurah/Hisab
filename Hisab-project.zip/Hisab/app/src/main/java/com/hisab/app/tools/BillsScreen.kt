@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.hisab.app.data.*
import com.hisab.app.ui.EarnGreen
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard
import com.hisab.app.ui.SpendRed
import com.hisab.app.ui.money
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private val Orange = Color(0xFFE67E22)

fun billIcon(type: String): ImageVector = when (type) {
    "Electricity" -> Icons.Rounded.Bolt
    "Mobile" -> Icons.Rounded.PhoneAndroid
    "Internet" -> Icons.Rounded.Wifi
    "EMI" -> Icons.Rounded.AccountBalance
    "Rent" -> Icons.Rounded.Home
    "Gas" -> Icons.Rounded.LocalFireDepartment
    "Water" -> Icons.Rounded.WaterDrop
    "Insurance" -> Icons.Rounded.Shield
    "School fees" -> Icons.Rounded.School
    else -> Icons.Rounded.ReceiptLong
}

private fun billCategory(type: String) = when (type) {
    "Mobile", "Internet" -> Category.RECHARGE
    "Rent" -> Category.RENT
    "School fees" -> Category.EDUCATION
    else -> Category.BILLS
}

@Composable
fun BillsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val bills = rememberItems { Bill.all() }
    var editing by remember { mutableStateOf<Bill?>(null) }
    var adding by remember { mutableStateOf(false) }
    var paying by remember { mutableStateOf<Bill?>(null) }
    val month = YearMonth.now()
    val today = LocalDate.now()

    val sorted = bills.sortedWith(compareBy<Bill> { it.isPaid(month) }.thenBy { it.dueDate(month) })
    val pendingTotal = bills.filter { !it.isPaid(month) }.sumOf { it.amount }

    ToolScaffold("Bill Reminder", onBack, fabText = "Add bill", onFab = { adding = true }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { NotificationPermissionCard() }
            item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = SpendRed.copy(alpha = 0.10f))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("${month.format(DateTimeFormatter.ofPattern("MMMM"))} bills pending", style = MaterialTheme.typography.labelLarge, color = SpendRed)
                        Text(money(pendingTotal), style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "${bills.count { it.isPaid(month) }} of ${bills.size} paid this month",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (bills.isEmpty()) item {
                SectionCard { EmptyState(Icons.Rounded.ReceiptLong, "No bills added", "Add electricity, mobile, EMI or rent. You'll get an alert before the due date.") }
            }
            items(sorted, key = { it.id }) { b ->
                val paid = b.isPaid(month)
                val due = b.dueDate(month)
                val days = ChronoUnit.DAYS.between(today, due)
                val (statusText, statusColor) = when {
                    paid -> "Paid for ${month.format(DateTimeFormatter.ofPattern("MMM"))} ✓" to EarnGreen
                    days < 0 -> "Overdue by ${-days} day${if (days == -1L) "" else "s"}" to SpendRed
                    days == 0L -> "Due today" to SpendRed
                    days <= 3 -> "Due in $days day${if (days == 1L) "" else "s"}" to Orange
                    else -> "Due ${due.format(DateTimeFormatter.ofPattern("d MMM"))} · in $days days" to MaterialTheme.colorScheme.onSurfaceVariant
                }
                Card(
                    onClick = { editing = b }, shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        val iconColor = if (paid) EarnGreen else if (days <= 3) statusColor else MaterialTheme.colorScheme.primary
                        IconCircle(billIcon(b.type), iconColor)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(b.name, style = MaterialTheme.typography.titleMedium)
                            Text(statusText, style = MaterialTheme.typography.bodyMedium, color = statusColor)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(money(b.amount), style = MaterialTheme.typography.titleMedium)
                            if (!paid) TextButton(onClick = { paying = b }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Mark paid") }
                        }
                    }
                }
            }
        }
    }

    if (adding) BillSheet(null) { adding = false }
    editing?.let { BillSheet(it) { editing = null } }
    paying?.let { b ->
        var addExpense by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { paying = null },
            title = { Text("Mark ${b.name} as paid?") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = addExpense, onCheckedChange = { addExpense = it })
                    Text("Also add ${money(b.amount)} to my expenses")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val saved = Bill.save(b.copy(paid = b.paid + month.toString()))
                    Reminders.scheduleBill(context, saved)
                    if (addExpense) Repository.save(
                        Txn(
                            amount = b.amount, type = TxnType.DEBIT, mode = Mode.UPI, category = billCategory(b.type),
                            party = b.name, note = "${b.type} bill", source = Source.MANUAL,
                            time = LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        )
                    )
                    paying = null
                }) { Text("Paid") }
            },
            dismissButton = { TextButton(onClick = { paying = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun BillSheet(existing: Bill?, onDone: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "Electricity") }
    var amount by remember { mutableStateOf(existing?.amount?.plain() ?: "") }
    var dueDay by remember { mutableStateOf(existing?.dueDay?.toString() ?: "") }
    var before by remember { mutableStateOf(existing?.remindBefore ?: 2) }
    val day = dueDay.toIntOrNull()

    ModalBottomSheet(onDismissRequest = onDone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (existing == null) "New bill" else "Edit bill", style = MaterialTheme.typography.titleLarge)
            Text("Type", style = MaterialTheme.typography.labelLarge)
            ChipRow(Bill.TYPES, type) { type = it; if (name.isBlank() || Bill.TYPES.contains(name)) name = it }
            Field(name, { name = it.take(40) }, "Bill name (e.g. MSEB, Jio, Car EMI)")
            Field(amount, { amount = it.take(9) }, "Amount", number = true, prefix = "₹ ")
            Field(dueDay, { v -> if (v.length <= 2 && v.all { it.isDigit() }) dueDay = v }, "Due day of month (1–31)", number = true)
            Text("Remind me", style = MaterialTheme.typography.labelLarge)
            ChipRow(listOf("Same day", "1 day before", "2 days before", "3 days before", "5 days before", "7 days before"),
                when (before) { 0 -> "Same day"; 1 -> "1 day before"; else -> "$before days before" }) {
                before = if (it == "Same day") 0 else it.substringBefore(' ').toInt()
            }
            Text(
                "Alert comes at 9:00 AM, again on the due day, and once more the next day if still unpaid. Repeats every month.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            PrimaryButton("Save", enabled = name.isNotBlank() && day != null && day in 1..31) {
                val saved = Bill.save(Bill(existing?.id ?: 0, name.trim(), type, amount.toAmount(), day ?: 1, before, existing?.paid ?: emptySet()))
                Reminders.scheduleBill(context, saved)
                onDone()
            }
            if (existing != null) {
                TextButton(onClick = {
                    Reminders.cancel(context, Reminders.KIND_BILL, existing.id)
                    Repository.deleteItem(existing.id); onDone()
                }, modifier = Modifier.fillMaxWidth()) { Text("Delete bill", color = SpendRed) }
            }
        }
    }
}

/** Shown on reminder screens until the user allows notifications (Android 13+). */
@Composable
fun NotificationPermissionCard() {
    val context = LocalContext.current
    var allowed by remember { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        allowed = NotificationManagerCompat.from(context).areNotificationsEnabled()
    }
    if (allowed) return
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.NotificationsActive, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text("Allow notifications so reminders can alert you", modifier = Modifier.weight(1f))
            TextButton(onClick = {
                if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else com.hisab.app.ui.Permissions.openAppInfo(context)
            }) { Text("Allow") }
        }
    }
}
