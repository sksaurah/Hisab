package com.hisab.app.tools

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.hisab.app.R
import com.hisab.app.data.Repository
import com.hisab.app.ui.MainActivity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId

/**
 * One place for every reminder in the app: medicine alarms, bill alerts and note reminders.
 * Alarms survive reboot (BootReceiver calls [rescheduleAll]).
 */
object Reminders {
    const val CH_MED = "medicine"
    const val CH_REMIND = "reminders"

    const val KIND_MED = "med"
    const val KIND_BILL = "bill"
    const val KIND_NOTE = "note"

    private const val ACTION_FIRE = "com.hisab.app.REMINDER"
    const val ACTION_TAKEN = "com.hisab.app.TAKEN"

    fun createChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val med = NotificationChannel(CH_MED, "Medicine alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Time to take your medicine"
            enableVibration(true)
            setSound(alarmSound, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        }
        val rem = NotificationChannel(CH_REMIND, "Bills & reminders", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Bill due dates and note reminders"
        }
        nm.createNotificationChannel(med)
        nm.createNotificationChannel(rem)
    }

    // ---------------------------------------------------------------- scheduling

    private fun requestCode(kind: String, id: Long, slot: Int) = when (kind) {
        KIND_MED -> 100_000 + (id * 10 + slot).toInt()
        KIND_BILL -> 300_000 + id.toInt()
        else -> 500_000 + id.toInt()
    }

    private fun firePending(context: Context, kind: String, id: Long, slot: Int): PendingIntent {
        val i = Intent(context, ReminderReceiver::class.java).setAction(ACTION_FIRE)
            .putExtra("kind", kind).putExtra("id", id).putExtra("slot", slot)
        return PendingIntent.getBroadcast(
            context, requestCode(kind, id, slot), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openAppPending(context: Context): PendingIntent = PendingIntent.getActivity(
        context, 1, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun scheduleAt(context: Context, at: LocalDateTime, kind: String, id: Long, slot: Int) {
        val am = context.getSystemService(AlarmManager::class.java)
        val millis = at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val pi = firePending(context, kind, id, slot)
        val exactOk = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exactOk) am.setAlarmClock(AlarmManager.AlarmClockInfo(millis, openAppPending(context)), pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        }
    }

    fun cancel(context: Context, kind: String, id: Long, slots: Int = 1) {
        val am = context.getSystemService(AlarmManager::class.java)
        for (s in 0 until slots) am.cancel(firePending(context, kind, id, s))
    }

    /** Medicine: next occurrence of each time slot. */
    fun scheduleMedicine(context: Context, m: Medicine) {
        cancel(context, KIND_MED, m.id, 10)
        if (!m.enabled) return
        m.times.forEachIndexed { slot, t ->
            var at = LocalDateTime.of(LocalDate.now(), t)
            if (!at.isAfter(LocalDateTime.now())) at = at.plusDays(1)
            scheduleAt(context, at, KIND_MED, m.id, slot)
        }
    }

    /** Bill: next reminder day (X days before due) or due day, 9:00 AM, in an unpaid month. */
    fun scheduleBill(context: Context, b: Bill) {
        cancel(context, KIND_BILL, b.id)
        val next = b.nextAlert(LocalDateTime.now()) ?: return
        scheduleAt(context, next, KIND_BILL, b.id, 0)
    }

    fun scheduleNote(context: Context, n: Note) {
        cancel(context, KIND_NOTE, n.id)
        val at = n.remindAt ?: return
        if (at.isAfter(LocalDateTime.now())) scheduleAt(context, at, KIND_NOTE, n.id, 0)
    }

    fun rescheduleAll(context: Context) {
        Repository.init(context)
        Medicine.all().forEach { scheduleMedicine(context, it) }
        Bill.all().forEach { scheduleBill(context, it) }
        Note.all().forEach { scheduleNote(context, it) }
    }

    // ---------------------------------------------------------------- showing

    fun notify(context: Context, notifId: Int, channel: String, title: String, text: String, builderExtra: (NotificationCompat.Builder) -> Unit = {}) {
        val b = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppPending(context))
        builderExtra(b)
        try {
            NotificationManagerCompat.from(context).notify(notifId, b.build())
        } catch (e: SecurityException) {
            // Notification permission not given
        }
    }

    fun handleFire(context: Context, kind: String, id: Long, slot: Int) {
        Repository.init(context)
        when (kind) {
            KIND_MED -> {
                val m = Medicine.load(id) ?: return
                if (m.enabled && slot in m.times.indices) {
                    val takenIntent = Intent(context, ReminderReceiver::class.java).setAction(ACTION_TAKEN)
                        .putExtra("id", id).putExtra("slot", slot)
                    val takenPi = PendingIntent.getBroadcast(
                        context, 700_000 + (id * 10 + slot).toInt(), takenIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    notify(
                        context, requestCode(KIND_MED, id, slot), CH_MED,
                        "💊 Time for ${m.name}",
                        listOf(m.dose, m.times[slot].label()).filter { it.isNotBlank() }.joinToString(" · ")
                    ) {
                        it.addAction(0, "✓ Taken", takenPi)
                        it.setCategory(NotificationCompat.CATEGORY_ALARM)
                        it.setAutoCancel(false)
                    }
                }
                scheduleMedicine(context, m)
            }
            KIND_BILL -> {
                val b = Bill.load(id) ?: return
                val month = YearMonth.now()
                if (!b.isPaid(month)) {
                    val due = b.dueDate(month)
                    val days = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), due)
                    val whenText = when {
                        days < 0 -> "was due on ${due.dayOfMonth} ${due.month.name.lowercase().replaceFirstChar { it.uppercase() }}"
                        days == 0L -> "is due TODAY"
                        days == 1L -> "is due tomorrow"
                        else -> "is due in $days days"
                    }
                    notify(
                        context, requestCode(KIND_BILL, id, 0), CH_REMIND,
                        "🧾 ${b.name} bill $whenText",
                        "Amount ${com.hisab.app.ui.money(b.amount)}. Open Hisab to mark it paid."
                    )
                }
                scheduleBill(context, b)
            }
            KIND_NOTE -> {
                val n = Note.load(id) ?: return
                notify(context, requestCode(KIND_NOTE, id, 0), CH_REMIND, "🔔 Reminder", n.text.take(300))
            }
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1)
        val slot = intent.getIntExtra("slot", 0)
        if (intent.action == Reminders.ACTION_TAKEN) {
            Repository.init(context)
            Medicine.load(id)?.let { Medicine.markTaken(it, LocalDate.now(), slot, true) }
            NotificationManagerCompat.from(context).cancel(100_000 + (id * 10 + slot).toInt())
            return
        }
        val kind = intent.getStringExtra("kind") ?: return
        Reminders.handleFire(context, kind, id, slot)
    }
}

/** Puts all alarms back after the phone restarts (Android clears alarms on reboot). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            Reminders.rescheduleAll(context)
        }
    }
}

fun LocalTime.label(): String = format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))
