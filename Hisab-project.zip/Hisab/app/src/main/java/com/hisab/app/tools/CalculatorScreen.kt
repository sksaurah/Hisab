@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hisab.app.ui.EarnGreen
import com.hisab.app.ui.SpendRed
import com.hisab.app.ui.money

private val tabs = listOf("Basic", "%", "GST", "Discount", "EMI", "Interest")

@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    ToolScaffold("Calculator", onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 12.dp, containerColor = MaterialTheme.colorScheme.background) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> BasicCalcPane()
                else -> Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).imePadding(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (tab) {
                        1 -> PercentPane()
                        2 -> GstPane()
                        3 -> DiscountPane()
                        4 -> EmiPane()
                        5 -> InterestPane()
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Basic keypad

@Composable
private fun BasicCalcPane() {
    var expr by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var done by remember { mutableStateOf(false) }

    fun preview(e: String) = runCatching { fmt(BasicCalc.eval(e)) }.getOrDefault("")

    fun press(k: String) {
        when (k) {
            "C" -> { expr = ""; result = ""; done = false }
            "⌫" -> { expr = expr.dropLast(1); done = false; result = preview(expr) }
            "=" -> {
                val r = runCatching { fmt(BasicCalc.eval(expr)) }.getOrElse { it.message ?: "Error" }
                result = r; done = true
            }
            else -> {
                val isOp = k in listOf("+", "−", "×", "÷", "%")
                if (done) { expr = if (isOp && result.toDoubleOrNull() != null) result + k else k; done = false }
                else expr += k
                result = preview(expr)
            }
        }
    }

    val keys = listOf(
        listOf("C", "⌫", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "−"),
        listOf("1", "2", "3", "+"),
        listOf("00", "0", ".", "=")
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Column(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.End) {
            Text(expr.ifEmpty { "0" }, fontSize = 34.sp, textAlign = TextAlign.End, maxLines = 3, lineHeight = 40.sp)
            Text(
                if (result.isEmpty()) "" else "= $result", fontSize = if (done) 44.sp else 26.sp, fontWeight = FontWeight.SemiBold,
                color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(12.dp))
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { k ->
                    val op = k in listOf("÷", "×", "−", "+", "%")
                    val eq = k == "="
                    Button(
                        onClick = { press(k) },
                        modifier = Modifier.weight(1f).height(68.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when {
                                eq -> MaterialTheme.colorScheme.primary
                                op -> MaterialTheme.colorScheme.primaryContainer
                                k == "C" || k == "⌫" -> SpendRed.copy(alpha = 0.12f)
                                else -> MaterialTheme.colorScheme.surface
                            },
                            contentColor = when {
                                eq -> MaterialTheme.colorScheme.onPrimary
                                op -> MaterialTheme.colorScheme.onPrimaryContainer
                                k == "C" || k == "⌫" -> SpendRed
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) { Text(k, fontSize = 26.sp) }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

private fun fmt(v: Double): String {
    if (v.isNaN() || v.isInfinite()) return "Error"
    val r = java.math.BigDecimal(v).round(java.math.MathContext(12)).stripTrailingZeros()
    return r.toPlainString()
}

// ---------------------------------------------------------------- shared result UI

@Composable
private fun ResultCard(rows: List<Pair<String, String>>, highlight: Int = rows.lastIndex, color: Color = MaterialTheme.colorScheme.primary) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.09f))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            rows.forEachIndexed { i, (k, v) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(k, modifier = Modifier.weight(1f), style = if (i == highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge)
                    Text(
                        v, style = if (i == highlight) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleMedium,
                        color = if (i == highlight) color else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Percentage

@Composable
private fun PercentPane() {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    Text("X% of Y", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Field(a, { a = it }, "Percent", Modifier.weight(1f), number = true, suffix = "%")
        Field(b, { b = it }, "of amount", Modifier.weight(1f), number = true)
    }
    if (a.isNotBlank() && b.isNotBlank()) ResultCard(listOf("${a}% of $b" to fmt(a.toAmount() * b.toAmount() / 100)))

    var c by remember { mutableStateOf("") }
    var d by remember { mutableStateOf("") }
    Spacer(Modifier.height(8.dp))
    Text("X is what % of Y", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Field(c, { c = it }, "Value", Modifier.weight(1f), number = true)
        Field(d, { d = it }, "Total", Modifier.weight(1f), number = true)
    }
    if (c.isNotBlank() && d.toAmount() != 0.0) ResultCard(listOf("Percentage" to fmt(c.toAmount() / d.toAmount() * 100) + "%"))

    var e by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("") }
    Spacer(Modifier.height(8.dp))
    Text("Increase / decrease", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Field(e, { e = it }, "Old value", Modifier.weight(1f), number = true)
        Field(f, { f = it }, "New value", Modifier.weight(1f), number = true)
    }
    if (e.toAmount() != 0.0 && f.isNotBlank()) {
        val ch = (f.toAmount() - e.toAmount()) / e.toAmount() * 100
        ResultCard(listOf((if (ch >= 0) "Increase" else "Decrease") to fmt(kotlin.math.abs(ch)) + "%"), color = if (ch >= 0) EarnGreen else SpendRed)
    }
}

// ---------------------------------------------------------------- GST

@Composable
private fun GstPane() {
    var amount by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("18%") }
    var add by remember { mutableStateOf(true) }
    Field(amount, { amount = it }, "Amount", number = true, prefix = "₹ ")
    Text("GST rate", style = MaterialTheme.typography.labelLarge)
    ChipRow(listOf("3%", "5%", "12%", "18%", "28%", "40%"), rate) { rate = it }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ToggleBox("Add GST", "Price is without GST", MaterialTheme.colorScheme.primary, add, Modifier.weight(1f)) { add = true }
        ToggleBox("Remove GST", "Price includes GST", MaterialTheme.colorScheme.primary, !add, Modifier.weight(1f)) { add = false }
    }
    val amt = amount.toAmount()
    if (amt > 0) {
        val r = rate.removeSuffix("%").toDouble()
        val g = MoneyMath.gst(amt, r, add)
        ResultCard(
            listOf(
                "Price before GST" to money(g.base),
                "CGST (${fmt(r / 2)}%)" to money(g.gst / 2),
                "SGST (${fmt(r / 2)}%)" to money(g.gst / 2),
                "Total GST" to money(g.gst),
                "Final price" to money(g.total)
            )
        )
        Text("For sales to another state, IGST = total GST.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- Discount

@Composable
private fun DiscountPane() {
    var price by remember { mutableStateOf("") }
    var off by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("") }
    Field(price, { price = it }, "Original price (MRP)", number = true, prefix = "₹ ")
    Field(off, { off = it }, "Discount", number = true, suffix = "% off")
    Field(extra, { extra = it }, "Extra discount (optional)", number = true, suffix = "% off")
    val p = price.toAmount()
    if (p > 0) {
        val after1 = p * (1 - off.toAmount() / 100)
        val final = after1 * (1 - extra.toAmount() / 100)
        val saved = p - final
        ResultCard(
            listOf(
                "You save" to money(saved),
                "Total discount" to fmt(saved / p * 100) + "%",
                "You pay" to money(final)
            ), color = EarnGreen
        )
    }
}

// ---------------------------------------------------------------- EMI

@Composable
private fun EmiPane() {
    var loan by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var tenure by remember { mutableStateOf("") }
    var years by remember { mutableStateOf(true) }
    Field(loan, { loan = it }, "Loan amount", number = true, prefix = "₹ ")
    Field(rate, { rate = it }, "Interest rate (yearly)", number = true, suffix = "%")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Field(tenure, { tenure = it }, "Tenure", Modifier.weight(1f), number = true)
        FilterChip(selected = years, onClick = { years = true }, label = { Text("Years") })
        FilterChip(selected = !years, onClick = { years = false }, label = { Text("Months") })
    }
    val p = loan.toAmount()
    val months = (tenure.toAmount() * if (years) 12 else 1).toInt()
    if (p > 0 && months > 0) {
        val emi = MoneyMath.emi(p, rate.toAmount(), months)
        val total = emi * months
        ResultCard(
            listOf(
                "Principal" to money(p),
                "Total interest" to money(total - p),
                "Total payment" to money(total),
                "Monthly EMI" to money(kotlin.math.round(emi))
            )
        )
        // Principal vs interest bar
        val share = (p / total).toFloat()
        Row(Modifier.fillMaxWidth().height(14.dp)) {
            Surface(Modifier.weight(share.coerceIn(0.01f, 0.99f)).fillMaxHeight(), color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(topStart = 7.dp, bottomStart = 7.dp)) {}
            Surface(Modifier.weight((1 - share).coerceIn(0.01f, 0.99f)).fillMaxHeight(), color = SpendRed, shape = RoundedCornerShape(topEnd = 7.dp, bottomEnd = 7.dp)) {}
        }
        Text("■ Principal ${(share * 100).toInt()}%   ■ Interest ${100 - (share * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
    }
}

// ---------------------------------------------------------------- Interest

@Composable
private fun InterestPane() {
    var p by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var yrs by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Simple") }
    Field(p, { p = it }, "Amount (principal)", number = true, prefix = "₹ ")
    Field(rate, { rate = it }, "Interest rate (yearly)", number = true, suffix = "%")
    Field(yrs, { yrs = it }, "Time", number = true, suffix = "years")
    ChipRow(listOf("Simple", "Yearly", "Half-yearly", "Quarterly", "Monthly"), mode) { mode = it }
    Text(
        if (mode == "Simple") "Simple interest" else "Compound interest, added $mode".lowercase().replaceFirstChar { it.uppercase() },
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    val principal = p.toAmount()
    val years = yrs.toAmount()
    if (principal > 0 && years > 0) {
        val r = rate.toAmount()
        val final = when (mode) {
            "Simple" -> principal + MoneyMath.simpleInterest(principal, r, years)
            "Yearly" -> MoneyMath.compoundAmount(principal, r, years, 1)
            "Half-yearly" -> MoneyMath.compoundAmount(principal, r, years, 2)
            "Quarterly" -> MoneyMath.compoundAmount(principal, r, years, 4)
            else -> MoneyMath.compoundAmount(principal, r, years, 12)
        }
        ResultCard(listOf("Principal" to money(principal), "Interest earned" to money(final - principal), "Maturity amount" to money(final)), color = EarnGreen)
    }
}
