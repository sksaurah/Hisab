@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hisab.app.data.*
import com.hisab.app.steps.StepTracker
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(
    modifier: Modifier,
    resumeTick: Int,
    onAdd: (EditorRequest) -> Unit,
    onOpen: (Txn) -> Unit,
    onSeeAll: () -> Unit,
    onSteps: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val txns by Repository.txns.collectAsState()
    val steps by Repository.steps.collectAsState()
    val goal by Prefs.stepGoal.collectAsState()
    val stride by Prefs.strideCm.collectAsState()

    val month = YearMonth.now()
    val monthTxns = remember(txns) { txns.filter { YearMonth.from(it.time.toLocalDate()) == month } }
    val spent = monthTxns.filter { it.type == TxnType.DEBIT && it.category.countsAsSpend }.sumOf { it.amount }
    val received = monthTxns.filter { it.type == TxnType.CREDIT }.sumOf { it.amount }
    val cashInHand = remember(txns) {
        txns.sumOf {
            when {
                it.mode == Mode.CASH && it.type == TxnType.CREDIT -> it.amount
                it.mode == Mode.CASH && it.type == TxnType.DEBIT -> -it.amount
                it.category == Category.ATM && it.type == TxnType.DEBIT -> it.amount  // ATM cash goes into your pocket
                else -> 0.0
            }
        }
    }
    val todaySpent = txns.filter { it.time.toLocalDate() == LocalDate.now() && it.type == TxnType.DEBIT && it.category.countsAsSpend }
        .sumOf { it.amount }
    val byCategory = monthTxns.filter { it.type == TxnType.DEBIT && it.category.countsAsSpend }
        .groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
        .entries.sortedByDescending { it.value }

    val captureOn = remember(resumeTick) { Permissions.notificationAccess(context) || Permissions.sms(context) }
    val todaySteps = steps[LocalDate.now()] ?: 0

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp, vertical = 4.dp)) {
                Text("Hisab", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // ---- Summary hero card
        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Brand, BrandDark)))
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        "${month.format(DateTimeFormatter.ofPattern("MMMM"))} spending",
                        color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge
                    )
                    Text(money(spent), color = Color.White, style = MaterialTheme.typography.headlineLarge)
                    Text(
                        "Today ${money(todaySpent)}",
                        color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HeroStat(Icons.Rounded.ArrowDownward, "Received", money(received), Modifier.weight(1f))
                        HeroStat(Icons.Rounded.Payments, "Cash in hand", money(cashInHand), Modifier.weight(1f))
                    }
                }
            }
        }

        // ---- Quick cash buttons
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickButton(
                    "Cash spent", Icons.Rounded.RemoveCircleOutline, SpendRed, Modifier.weight(1f)
                ) { onAdd(EditorRequest(type = TxnType.DEBIT, mode = Mode.CASH)) }
                QuickButton(
                    "Cash received", Icons.Rounded.AddCircleOutline, EarnGreen, Modifier.weight(1f)
                ) { onAdd(EditorRequest(type = TxnType.CREDIT, mode = Mode.CASH)) }
            }
        }

        // ---- Auto-capture banner
        if (!captureOn) item {
            Card(
                onClick = onSettings,
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Turn on auto-capture", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Record GPay, PhonePe, Paytm & bank SMS payments automatically",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Icon(Icons.Rounded.ChevronRight, null)
                }
            }
        }

        // ---- Steps mini card
        if (StepTracker.hasSensor(context)) item {
            SectionCard(Modifier.clickable(onClick = onSteps)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ring((todaySteps.toFloat() / goal), StepBlue, 64.dp, 8.dp) {
                        Icon(Icons.Rounded.DirectionsWalk, null, tint = StepBlue)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Steps today", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(groupThousands(todaySteps), style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "%.2f km · goal %s".format(StepTracker.distanceKm(todaySteps, stride), groupThousands(goal)),
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // ---- Category breakdown
        if (byCategory.isNotEmpty()) item {
            SectionCard(title = "Where your money went") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Donut(byCategory.map { it.key.color() to it.value }) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Spent", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(money(spent), style = MaterialTheme.typography.titleMedium)
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        byCategory.take(5).forEach { (cat, amt) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).clip(CircleShape).background(cat.color()))
                                Spacer(Modifier.width(8.dp))
                                Text(cat.label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1)
                                Text(
                                    "${(amt / spent * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---- Recent
        item {
            SectionCard(title = "Recent", action = if (txns.isNotEmpty()) "See all" else null, onAction = onSeeAll) {
                if (txns.isEmpty()) {
                    EmptyState(
                        Icons.Rounded.ReceiptLong, "No entries yet",
                        "Tap “Add entry” for cash, or turn on auto-capture for UPI & bank payments."
                    )
                } else {
                    txns.take(6).forEach { TxnRow(it) { onOpen(it) } }
                }
            }
        }
    }
}

@Composable
private fun HeroStat(icon: ImageVector, label: String, value: String, modifier: Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.12f)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelMedium)
            Text(value, color = Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        }
    }
}

@Composable
private fun QuickButton(label: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = modifier.height(56.dp), shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color)
            Spacer(Modifier.width(10.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
