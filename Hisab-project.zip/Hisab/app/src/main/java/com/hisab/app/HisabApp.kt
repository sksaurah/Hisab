package com.hisab.app

import android.app.Application
import com.hisab.app.data.Prefs
import com.hisab.app.data.Repository
import com.hisab.app.steps.StepTracker
import com.hisab.app.tools.Reminders

class HisabApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Repository.init(this)
        if (StepTracker.hasSensor(this)) StepTracker.schedule(this)
        Reminders.createChannels(this)
        runCatching { Reminders.rescheduleAll(this) }
    }
}
