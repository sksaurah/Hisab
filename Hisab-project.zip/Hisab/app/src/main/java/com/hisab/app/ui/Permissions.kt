package com.hisab.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Permissions {
    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun notificationAccess(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    fun sms(c: Context) = granted(c, Manifest.permission.READ_SMS) && granted(c, Manifest.permission.RECEIVE_SMS)
    fun activity(c: Context) = Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACTIVITY_RECOGNITION)
    fun batteryFree(c: Context) = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

    val smsPerms = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)
    val activityPerms = if (Build.VERSION.SDK_INT >= 29) arrayOf(Manifest.permission.ACTIVITY_RECOGNITION) else emptyArray()

    fun openNotificationAccess(c: Context) = safeStart(c, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openAppInfo(c: Context) = safeStart(
        c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}"))
    )

    @SuppressLint("BatteryLife")
    fun openBattery(c: Context) {
        val ok = safeStart(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}")))
        if (!ok) safeStart(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private fun safeStart(c: Context, i: Intent): Boolean = try {
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }
}
