package com.hisab.app.ui

import android.icu.text.NumberFormat
import android.icu.util.ULocale
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hisab.app.data.Category
import com.hisab.app.data.Txn
import com.hisab.app.data.TxnType
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ---------------------------------------------------------------- formatting

private val rupee: NumberFormat = NumberFormat.getCurrencyInstance(ULocale("en_IN")).apply {
    maximumFractionDigits = 2
    minimumFractionDigits = 0
}

/** ₹1,23,456 (Indian grouping) */
fun money(v: Double): String = rupee.format(v)

fun signedMoney(t: Txn) = (if (t.type == TxnType.DEBIT) "− " else "+ ") + money(t.amount)

fun Long.toLocalDate(): LocalDate = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()

private val timeFmt = DateTimeFormatter.ofPattern("h:mm a")
fun Long.timeText(): String = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalTime().format(timeFmt)

fun LocalDate.dayHeader(): String {
    val today = LocalDate.now()
    return when (this) {
        today -> "Today"
        today.minusDays(1) -> "Yesterday"
        else -> format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy"))
    }
}

fun groupThousands(n: Int): String = NumberFormat.getIntegerInstance(ULocale("en_IN")).format(n.toLong())

// ---------------------------------------------------------------- category look

fun Category.icon(): ImageVector = when (this) {
    Category.FOOD -> Icons.Rounded.Restaurant
    Category.GROCERY -> Icons.Rounded.ShoppingCart
    Category.MILK -> Icons.Rounded.LocalDrink
    Category.TRAVEL -> Icons.Rounded.DirectionsCar
    Category.FUEL -> Icons.Rounded.LocalGasStation
    Category.BILLS -> Icons.Rounded.Bolt
    Category.RECHARGE -> Icons.Rounded.PhoneAndroid
    Category.SHOPPING -> Icons.Rounded.ShoppingBag
    Category.HEALTH -> Icons.Rounded.LocalHospital
    Category.RENT -> Icons.Rounded.Home
    Category.EDUCATION -> Icons.Rounded.School
    Category.ENTERTAINMENT -> Icons.Rounded.Movie
    Category.SALARY -> Icons.Rounded.Work
    Category.GIFT -> Icons.Rounded.CardGiftcard
    Category.ATM -> Icons.Rounded.LocalAtm
    Category.OTHER -> Icons.Rounded.MoreHoriz
}

fun Category.color(): Color = when (this) {
    Category.FOOD -> Color(0xFFF2994A)
    Category.GROCERY -> Color(0xFF27AE60)
    Category.MILK -> Color(0xFF56CCF2)
    Category.TRAVEL -> Color(0xFF2F80ED)
    Category.FUEL -> Color(0xFFEB5757)
    Category.BILLS -> Color(0xFFF2C94C)
    Category.RECHARGE -> Color(0xFF9B51E0)
    Category.SHOPPING -> Color(0xFFE84393)
    Category.HEALTH -> Color(0xFF00B894)
    Category.RENT -> Color(0xFF8D6E63)
    Category.EDUCATION -> Color(0xFF5C6BC0)
    Category.ENTERTAINMENT -> Color(0xFFFF7675)
    Category.SALARY -> Color(0xFF1E9E6A)
    Category.GIFT -> Color(0xFFFD79A8)
    Category.ATM -> Color(0xFF78909C)
    Category.OTHER -> Color(0xFF95A5A6)
}

@Composable
fun CategoryBadge(c: Category, size: Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(c.color().copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(c.icon(), contentDescription = c.label, tint = c.color(), modifier = Modifier.size(size * 0.5f))
    }
}

// ---------------------------------------------------------------- building blocks

@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    action: String? = null,
    onAction: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            if (title != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    if (action != null && onAction != null) {
                        TextButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(action) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            content()
        }
    }
}

@Composable
fun TxnRow(t: Txn, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CategoryBadge(t.category)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.party.ifBlank { t.category.label },
                style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${t.category.label} · ${t.mode.label} · ${t.time.timeText()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (t.isAuto) {
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        Icons.Rounded.AutoAwesome, contentDescription = "Auto captured",
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(
            signedMoney(t),
            style = MaterialTheme.typography.titleMedium,
            color = if (t.type == TxnType.DEBIT) SpendRed else EarnGreen
        )
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp)) }
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            text, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

// ---------------------------------------------------------------- charts

/** Donut chart of category totals. */
@Composable
fun Donut(parts: List<Pair<Color, Double>>, size: Dp = 132.dp, thickness: Dp = 18.dp, center: @Composable () -> Unit) {
    val total = parts.sumOf { it.second }
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = thickness.toPx()
            val inset = stroke / 2
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
            if (total > 0) {
                var start = -90f
                val gap = if (parts.size > 1) 2f else 0f
                for ((color, v) in parts) {
                    val sweep = (v / total * 360f).toFloat()
                    if (sweep > gap) drawArc(color, start + gap / 2, sweep - gap, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Butt))
                    start += sweep
                }
            }
        }
        center()
    }
}

/** Progress ring used for the steps goal. */
@Composable
fun Ring(progress: Float, color: Color, size: Dp, thickness: Dp, center: @Composable () -> Unit) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = thickness.toPx()
            val inset = stroke / 2
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
            drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        center()
    }
}

/** Simple vertical bar chart with labels underneath. */
@Composable
fun Bars(values: List<Float>, labels: List<String>, color: Color, highlightLast: Boolean = true, height: Dp = 140.dp, goal: Float? = null) {
    val max = maxOf(values.maxOrNull() ?: 0f, goal ?: 0f, 1f)
    val faded = color.copy(alpha = 0.35f)
    val goalColor = MaterialTheme.colorScheme.outlineVariant
    Column {
        Canvas(Modifier.fillMaxWidth().height(height)) {
            val n = values.size.coerceAtLeast(1)
            val slot = size.width / n
            val barW = slot * 0.56f
            if (goal != null) {
                val gy = size.height - (goal / max) * size.height
                drawLine(goalColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 2.dp.toPx())
            }
            values.forEachIndexed { i, v ->
                val h = (v / max) * size.height
                val c = if (!highlightLast || i == values.lastIndex) color else faded
                drawRoundRect(
                    c, topLeft = Offset(i * slot + (slot - barW) / 2, size.height - h),
                    size = Size(barW, h.coerceAtLeast(3f)), cornerRadius = CornerRadius(8.dp.toPx())
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            labels.forEach {
                Text(
                    it, modifier = Modifier.weight(1f), fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
