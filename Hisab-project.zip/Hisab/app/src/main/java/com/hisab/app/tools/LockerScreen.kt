@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import com.hisab.app.data.Repository
import com.hisab.app.ui.EmptyState
import com.hisab.app.ui.SectionCard
import com.hisab.app.ui.SpendRed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

private val LockerColor = Color(0xFF34495E)

/** PIN is stored only as a salted SHA-256 hash. */
object LockerPin {
    private fun prefs(c: Context) = c.getSharedPreferences("locker", Context.MODE_PRIVATE)
    fun isSet(c: Context) = prefs(c).contains("hash")
    private fun hash(pin: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun set(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        prefs(c).edit().putString("salt", salt).putString("hash", hash(pin, salt)).apply()
    }

    fun check(c: Context, pin: String): Boolean {
        val p = prefs(c)
        return hash(pin, p.getString("salt", "") ?: "") == p.getString("hash", null)
    }
}

object LockerFiles {
    fun dir(c: Context) = File(c.filesDir, "locker").apply { mkdirs() }
    fun file(c: Context, name: String) = File(dir(c), name)

    /** Copies the picked photo into private app storage (resized to max 2400 px). */
    fun import(c: Context, uri: Uri): String? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val bmp = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val name = UUID.randomUUID().toString() + ".jpg"
        file(c, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        name
    }.getOrNull()

    fun thumb(c: Context, name: String, maxPx: Int): ImageBitmap? = runCatching {
        val f = file(c, name)
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, b)
        var s = 1
        while (maxOf(b.outWidth, b.outHeight) / s > maxPx) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
    }.getOrNull()

    fun share(c: Context, d: Doc) {
        val uri = FileProvider.getUriForFile(c, "${c.packageName}.files", file(c, d.file))
        val i = Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, "Share ${d.title}"))
    }
}

@Composable
fun LockerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var unlocked by remember { mutableStateOf(false) }
    var pinSet by remember { mutableStateOf(LockerPin.isSet(context)) }
    var changingPin by remember { mutableStateOf(false) }

    // Block screenshots and the recent-apps preview while the locker is open
    DisposableEffect(Unit) {
        val w = (context as? Activity)?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    ToolScaffold(
        "Document Locker", onBack,
        actions = { if (unlocked) IconButton(onClick = { changingPin = true }) { Icon(Icons.Rounded.Password, "Change PIN") } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                !pinSet || changingPin -> PinSetup(isChange = changingPin) { pin ->
                    LockerPin.set(context, pin); pinSet = true; changingPin = false; unlocked = true
                }
                !unlocked -> PinLock { unlocked = true }
                else -> LockerContent()
            }
        }
    }
}

@Composable
private fun PinPad(title: String, subtitle: String, error: String?, showFingerprint: Boolean, onFingerprint: () -> Unit, onComplete: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        IconCircle(Icons.Rounded.Lock, LockerColor, 64.dp)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            repeat(4) { i ->
                Box(
                    Modifier.size(18.dp).clip(CircleShape)
                        .background(if (i < pin.length) LockerColor else MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }
        Text(error ?: "", color = SpendRed, modifier = Modifier.padding(top = 12.dp).height(20.dp))
        Spacer(Modifier.weight(1f))
        val keys = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf(if (showFingerprint) "FP" else "", "0", "⌫"))
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { k ->
                    if (k.isEmpty()) Spacer(Modifier.weight(1f).height(64.dp))
                    else FilledTonalButton(
                        onClick = {
                            when (k) {
                                "⌫" -> pin = pin.dropLast(1)
                                "FP" -> onFingerprint()
                                else -> if (pin.length < 4) {
                                    pin += k
                                    if (pin.length == 4) { val p = pin; pin = ""; onComplete(p) }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f).height(64.dp), shape = RoundedCornerShape(18.dp)
                    ) {
                        if (k == "FP") Icon(Icons.Rounded.Fingerprint, "Fingerprint", Modifier.size(28.dp))
                        else Text(k, fontSize = 26.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun PinSetup(isChange: Boolean, onDone: (String) -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    PinPad(
        title = if (first == null) (if (isChange) "Set a new PIN" else "Create a 4-digit PIN") else "Enter the PIN again",
        subtitle = "This PIN protects your documents. Don't forget it: there is no way to recover it.",
        error = error, showFingerprint = false, onFingerprint = {}
    ) { p ->
        val f = first
        if (f == null) { first = p; error = null }
        else if (f == p) onDone(p)
        else { first = null; error = "PINs didn't match. Try again." }
    }
}

@Composable
private fun PinLock(onUnlock: () -> Unit) {
    val context = LocalContext.current
    var error by remember { mutableStateOf<String?>(null) }
    val activity = context as? FragmentActivity
    val canBio = remember {
        BiometricManager.from(context).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        ) == BiometricManager.BIOMETRIC_SUCCESS && activity != null
    }
    val askBio: () -> Unit = {
        if (activity != null) {
            val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context), object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onUnlock() }
            })
            prompt.authenticate(
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock Document Locker")
                    .setSubtitle("Use your fingerprint")
                    .setNegativeButtonText("Use PIN")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    .build()
            )
        }
    }
    LaunchedEffect(Unit) { if (canBio) askBio() }
    PinPad("Locker is locked", "Enter your PIN or use fingerprint", error, canBio, askBio) { p ->
        if (LockerPin.check(context, p)) onUnlock() else error = "Wrong PIN"
    }
}

@Composable
private fun LockerContent() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val docs = rememberItems { Doc.all() }.sortedByDescending { it.added }
    var filter by remember { mutableStateOf("All") }
    var pendingFile by remember { mutableStateOf<String?>(null) }
    var viewing by remember { mutableStateOf<Doc?>(null) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            pendingFile = withContext(Dispatchers.IO) { LockerFiles.import(context, uri) }
            busy = false
        }
    }
    val cats = listOf("All") + Doc.CATEGORIES.filter { c -> docs.any { it.category == c } }
    val shown = if (filter == "All") docs else docs.filter { it.category == filter }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (docs.isNotEmpty()) item { ChipRow(cats, filter) { filter = it } }
            if (docs.isEmpty()) item {
                SectionCard { EmptyState(Icons.Rounded.Lock, "Your locker is empty", "Add photos of Aadhaar, PAN, licence or bills. They're stored only inside this app, protected by your PIN.") }
            }
            shown.chunked(2).forEach { pair ->
                item(key = pair.first().id) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        pair.forEach { d -> DocTile(d, Modifier.weight(1f)) { viewing = d } }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            icon = { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Icon(Icons.Rounded.AddAPhoto, null) },
            text = { Text("Add document") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary
        )
    }

    pendingFile?.let { f -> NewDocSheet(f) { pendingFile = null } }
    viewing?.let { d -> DocViewer(d) { viewing = null } }
}

@Composable
private fun DocTile(d: Doc, modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val img by produceState<ImageBitmap?>(null, d.file) { value = withContext(Dispatchers.IO) { LockerFiles.thumb(context, d.file, 400) } }
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Box(Modifier.fillMaxWidth().height(120.dp).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            val bmp = img
            if (bmp != null) Image(bmp, d.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.Description, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(Modifier.padding(10.dp)) {
            Text(d.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(d.category, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NewDocSheet(file: String, onDone: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Aadhaar") }
    var saved by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = {
        if (!saved) LockerFiles.file(context, file).delete()   // cancelled: remove the copied photo
        onDone()
    }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Save document", style = MaterialTheme.typography.titleLarge)
            ChipRow(Doc.CATEGORIES, cat) { cat = it; if (title.isBlank() || Doc.CATEGORIES.any { c -> title.startsWith(c) }) title = it }
            Field(title, { title = it.take(40) }, "Title (e.g. Aadhaar – Papa)")
            PrimaryButton("Save", enabled = title.isNotBlank()) {
                Doc.save(Doc(0, title.trim(), cat, file, System.currentTimeMillis()))
                saved = true
                onDone()
            }
        }
    }
}

@Composable
private fun DocViewer(d: Doc, onClose: () -> Unit) {
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    val img by produceState<ImageBitmap?>(null, d.file) { value = withContext(Dispatchers.IO) { LockerFiles.thumb(context, d.file, 2400) } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close", tint = Color.White) }
                    Column(Modifier.weight(1f)) {
                        Text(d.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(d.category, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium)
                    }
                    IconButton(onClick = { LockerFiles.share(context, d) }) { Icon(Icons.Rounded.Share, "Share", tint = Color.White) }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Delete", tint = Color.White) }
                }
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    val bmp = img
                    if (bmp != null) Image(bmp, d.title, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else CircularProgressIndicator(color = Color.White)
                }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${d.title}?") },
        text = { Text("The photo will be removed from the locker.") },
        confirmButton = {
            TextButton(onClick = {
                LockerFiles.file(context, d.file).delete()
                Repository.deleteItem(d.id)
                confirmDelete = false; onClose()
            }) { Text("Delete", color = SpendRed) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}
