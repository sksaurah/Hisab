package com.hisab.app.data

enum class TxnType { DEBIT, CREDIT }

enum class Mode(val label: String) {
    CASH("Cash"), UPI("UPI"), BANK("Bank"), CARD("Card")
}

enum class Source { MANUAL, NOTIFICATION, SMS }

/**
 * Spending / income categories.
 * [countsAsSpend] = false for money that only moves between your own pockets
 * (ATM withdrawal, self transfer), so it doesn't inflate "Spent".
 */
enum class Category(val label: String, val countsAsSpend: Boolean = true) {
    FOOD("Food & Dining"),
    GROCERY("Groceries"),
    MILK("Milk & Dairy"),
    TRAVEL("Travel"),
    FUEL("Fuel"),
    BILLS("Bills & Utilities"),
    RECHARGE("Mobile & DTH"),
    SHOPPING("Shopping"),
    HEALTH("Health"),
    RENT("Rent & Home"),
    EDUCATION("Education"),
    ENTERTAINMENT("Entertainment"),
    SALARY("Salary"),
    GIFT("Gift"),
    ATM("ATM / Self transfer", countsAsSpend = false),
    OTHER("Other");

    companion object {
        fun of(name: String?): Category = entries.firstOrNull { it.name == name } ?: OTHER
    }
}

data class Txn(
    val id: Long = 0,
    val amount: Double,
    val type: TxnType,
    val mode: Mode,
    val category: Category,
    val party: String,
    val note: String,
    val time: Long,
    val source: Source,
    val raw: String = ""
) {
    val isAuto get() = source != Source.MANUAL
}
