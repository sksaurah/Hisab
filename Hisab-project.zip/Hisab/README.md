# Hisab: Money & Steps

A simple daily app for everyone:
- **Auto-records payments** from Google Pay, PhonePe, Paytm, BHIM and bank SMS (SBI, HDFC, ICICI, Axis, Kotak…)
- **Cash in / cash out** entries in two taps
- **Cash in hand**, monthly spent/received, category chart, search and filters
- **Steps**: daily count, km, calories, 7-day chart and goal
- **Export to Excel (CSV)**
- **Tools tab**: Udhaar book (WhatsApp reminder), Bill reminder, All-in-one calculator (GST, EMI, discount, interest, %),
  Medicine reminder (alarms), Milk & maid attendance with monthly bill, Grocery list (share), Document locker
  (PIN + fingerprint), Big-text notes with reminders
- Works offline. No login. All data stays on the phone.

## Files
| File | What it does |
|---|---|
| `capture/TxnParser.kt` | Reads payment messages (amount, paid/received, name, UPI/card/bank) |
| `capture/PaymentNotificationListener.kt` | Reads UPI app and SMS notifications |
| `capture/SmsCapture.kt` | Live bank SMS + import last 90 days |
| `data/Repository.kt` | On-phone database, duplicate check |
| `steps/StepTracker.kt` | Step sensor + background reading every 15 min |
| `ui/*` | Screens: Home, History, Add/Edit, Steps, Settings |
